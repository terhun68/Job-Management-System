<?php
    session_start();
    require "../Connection.php";
    $errors = array();
    $email="";
    $username="";
    $country = "";
    $state = "";
    $postal_code = "";
    $address = "";
    $phone_no = "";

    // when user press register_student
    if(isset($_POST['register_student'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $conform_password = $_POST['conform_password'];
        $email = $_POST['email'];
        $country = $_POST['country'];
        $state = $_POST['state'];
        $postal_code = $_POST['postal_code'];
        $address = $_POST['address'];
        $phone_no = $_POST['phone_no'];
        $field = implode(',', $_POST['field']);
        $studentID = "s_".$email;
        $activate = 'activate';
        $reason = '';
        $comment = '';
        $permission = 'no';
        
        //check photo
        $photo=basename($_FILES["photo"]["name"]);
        $photo=$email.$photo;
        $target_dir = "../Photo_Student/";
        $target_file = $target_dir . $email.basename($_FILES["photo"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        if(isset($_POST["register_student"])) {
        $check = getimagesize($_FILES["photo"]["tmp_name"]);
        if($check !== false) {
            $uploadOk = 1;
        } else {
            $errors['photo'] = "Photo field is not an image type.";
            $uploadOk = 0;
        }
        }

        if ($_FILES["photo"]["size"] > 2000000) {
        $errors['photo'] = $errors['photo']." Sorry, your photo is too large.";
        $uploadOk = 0;
        }

        if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
        ) {
        $errors['photo'] = $errors['photo']." Sorry, only JPG, JPEG, PNG files are allowed for photo field.";
        $uploadOk = 0;
        }

        if ($uploadOk == 0) {
        $errors['photo'] = $errors['photo']." Sorry, your photo was not uploaded.";
        } 
        else {
        if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
            
        } else {

            echo "Sorry, there was an error uploading your photo.";
        }
        }

        //check cv
        $cv=basename($_FILES["cv"]["name"]);
        $cv=$email.$cv;
        $target_dir = "../CV_Student/";
        $target_file = $target_dir . $email.basename($_FILES["cv"]["name"]);
        $uploadOk = 1;
        $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

        if(isset($_POST["register_student"])) {
        $check = getimagesize($_FILES["cv"]["tmp_name"]);

        if (move_uploaded_file($_FILES["cv"]["tmp_name"], $target_file)) {
            
        } else {

            echo "Sorry, there was an error uploading your file.";
        }
        }

        // check password match or not
        if($password != $conform_password){
            $errors['password'] = "Confirm password not matched!";
        }

        // check email duplicate or not
        $email_check = "SELECT * FROM login_student WHERE email = '$email'";
        $result=$conn->query($email_check);
        if(mysqli_num_rows($result) > 0){
            $errors['email'] = "Email that you have entered is already exist!";
        }

        // check whether got error or not
        if(count($errors) == 0){
            $encpass = password_hash($password, PASSWORD_BCRYPT);
            $status = "not_verified";
            $code = rand(999999, 111111);
            $insert_data = "INSERT INTO login_student (studentID, username, password, email, country, state, postal_code, address, phone_no, field, photo, cv, code, status, activate, reason, comment, permission) 
            values('$studentID', '$username', '$encpass', '$email', '$country', '$state', '$postal_code', '$address', '$phone_no', '$field', '$photo', '$cv' , '$code', '$status', '$activate', '$reason', '$comment', '$permission')";

            $data_check = $conn->query($insert_data);
            if($data_check){
                $subject = "Email Verification Code For Student";
                $message = "Your verification code is $code";
                $sender = "From: B190202C@sc.edu.my";
                if(mail($email, $subject, $message, $sender)){
                    $info = "We've sent a verification code to your email : $email";
                    $_SESSION['info'] = $info;
                    $_SESSION['email'] = $email;
                    header('location: Student_OTP_Page.php');
                    exit();
                }else{
                    $errors['otp-error'] = "Failed while sending code!";
                }
            }else{
                $errors['db-error'] = "Failed while inserting data into database!";
            }
        }
    }

    //when user check their email at otp page
    if(isset($_POST['check_email_student'])){
        $otp_code = $_POST['otp'];
        $check_code = "SELECT * FROM login_student WHERE code = $otp_code";
        $code_result=$conn->query($check_code);
        if(mysqli_num_rows($code_result) > 0){
            $fetch_data = mysqli_fetch_assoc($code_result);
            $fetch_code = $fetch_data['code'];
            $email = $fetch_data['email'];
            $username = $fetch_data['username'];
            $code = 0;
            $status = 'verified';
            $update_otp = "UPDATE login_student SET code = $code, status = '$status' WHERE code = $fetch_code";
            $result=$conn->query($update_otp);
            if($result){
                $_SESSION['username'] = $username;
                $_SESSION['email'] = $email;
                header('location: ../Student/Student_Home.php');
                exit();
            }else{
                $errors['otp-error'] = "Failed while updating code!";
            }
        }else{
            $errors['otp-error'] = "You've entered incorrect code! Please try again.";
        }
    }

    //when user press resend otp
    if(isset($_POST['resend_code_student'])){
        $email = $_SESSION['email'];
        $email_get = "SELECT * FROM login_student WHERE email = '$email'";
        $email_result = $conn->query($email_get);
        
        if(mysqli_num_rows($email_result) > 0){
            $fetch_data = mysqli_fetch_assoc($email_result);
            $fetch_code = $fetch_data['code'];
            $code = rand(999999, 111111);
            $update_otp = "UPDATE login_student SET code = $code WHERE code = $fetch_code";
            $result=$conn->query($update_otp);
            if($update_otp){
                $subject = "Email Verification Code For Student";
                $message = "Your verification code is $code";
                $sender = "From: B190202C@sc.edu.my";
                if(mail($email, $subject, $message, $sender)){
                    $info = "We've resent a verification code to your email: $email, Please check again.";
                    $_SESSION['info'] = $info;
                    $_SESSION['email'] = $email;
                    header('location: Student_OTP_Page.php');
                    exit();
                }else{
                    $errors['otp-error'] = "Failed while sending code!";
                }
            }else{
                $errors['db-error'] = "Failed while inserting data into database!";
            }
        }
    }

    //when user press login
    if(isset($_POST['login_student'])){
        $email = $_POST['email'];
        $password = $_POST['password'];
        $check_email = "SELECT * FROM login_student WHERE email = '$email'";
        $res = $conn->query($check_email);

        if(mysqli_num_rows($res) > 0){
            $fetch = mysqli_fetch_assoc($res);
            $fetch_pass = $fetch['password'];
            $fetch_activate = $fetch['activate'];

            //check activate status
            if($fetch_activate == 'activate'){
                if(password_verify($password, $fetch_pass)){
                    $_SESSION['email'] = $email;
                    $status = $fetch['status'];
                    if($status == 'verified'){
                      $_SESSION['email'] = $email;
                      $_SESSION['password'] = $password;
                      header('location: ../Student/Student_Home.php');}
                                          
                      else{
                        $info = "It's look like you haven't still verify your email - $email";
                        $_SESSION['info'] = $info;
                        header('location: Student_OTP_Page.php');
                    }
                }else{
                    $errors['email'] = "Incorrect email or password!";
                }
            }else{
                $errors['deactivate'] = "Your account is deactivated now. Please contact us for activate.";
            }
        }else{
            $errors['email'] = "It's look like you're not yet a member! Click on the bottom link to register.";
        }
    }

    //when user forget password, press the submit email button
    if(isset($_POST['submit_forget_password_student'])){
        $email = $_POST['email'];
        $check_email = "SELECT * FROM login_student WHERE email='$email'";
        $run_sql = $conn->query($check_email);

        if(mysqli_num_rows($run_sql) > 0){
            $code = rand(999999, 111111);
            $insert_code = "UPDATE login_student SET code = $code WHERE email = '$email'";
            $run_query=$conn->query($insert_code);
            
            if($run_query){
                $subject = "Password Reset Code For Student";
                $message = "Your password reset code is $code";
                $sender = "From: B190202C@sc.edu.my";
                if(mail($email, $subject, $message, $sender)){
                    $info = "We've sent a passwrod reset otp to your email - $email";
                    $_SESSION['info'] = $info;
                    $_SESSION['email'] = $email;
                    header('location: Student_Reset_Code.php');
                    exit();
                }else{
                    $errors['otp-error'] = "Failed while sending code!";
                }
            }else{
                $errors['db-error'] = "Something went wrong!";
            }
        }else{
            $errors['email'] = "This email address does not exist!";
        }
    }

    //when user submit password reset code
    if(isset($_POST['submit_password_reset_student'])){
        $otp_code = $_POST['otp'];
        $check_code = "SELECT * FROM login_student WHERE code = $otp_code";
        $code_res=$conn->query($check_code);

        if(mysqli_num_rows($code_res) > 0){
            $fetch_data = mysqli_fetch_assoc($code_res);
            $email = $fetch_data['email'];
            $_SESSION['email'] = $email;
            $info = "Please create a new password that you don't use on any other site.";
            $_SESSION['info'] = $info;
            header('location: Student_Reset_Password.php');
            exit();
        }else{
            $errors['otp-error'] = "You've entered incorrect code!";
        }
    }

    //when user submit new password
    if(isset($_POST['submit_new_password_student'])){
        $password = $_POST['password'];
        $cpassword = $_POST['conform_password'];
        if($password !== $cpassword){
            $errors['password'] = "Conform password not matched!";
        }else{
            $code = 0;
            $email = $_SESSION['email']; //getting this email using session
            $encpass = password_hash($password, PASSWORD_BCRYPT);
            $update_pass = "UPDATE login_student SET code = $code, password = '$encpass' WHERE email = '$email'";
            $run_query=$conn->query($update_pass);
            
            if($run_query){
                //$info = "Your password changed. Now you can login with your new password.";
                //$_SESSION['info'] = $info;
                header('Location: Student_Success_Reset_Password.php');
            }else{
                $errors['db-error'] = "Failed to change your password!";
            }
        }
    }

?>

