<?php
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];
    $username = $_SESSION['username'];

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/Student_Login_Page.php');
    }

    if(isset($_POST['submit_new_password_student'])){
        $password = $_POST['password'];
        $cpassword = $_POST['conform_password'];
        if($password !== $cpassword){
            echo '<script>alert("Conform password not matched!")</script>';
        }else{
            $email = $_SESSION['email']; //getting this email using session
            $encpass = password_hash($password, PASSWORD_BCRYPT);
            $update_pass = "UPDATE login_student SET password = '$encpass' WHERE email = '$email'";
            $run_query=$conn->query($update_pass);
            
            if($run_query){
                //$info = "Your password changed. Now you can login with your new password.";
                //$_SESSION['info'] = $info;
                echo '<script> alert("Your password has been successful changed!"); location.href = "Student_Edit_Profile.php" </script>';
            }else{
                $errors['db-error'] = "Failed to change your password!";
            }
        }
    }

    if(isset($_POST['back'])){
        header('location: Student_Edit_Profile.php');
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Reset Password Page</title>
    <link rel="stylesheet" type="text/css" href="../Visitor/Student_Forget_Password_CSS.css">
    <link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../Visitor/css/styles.css" rel="stylesheet" />
</head>
<body class="d-flex flex-column">
<main class="flex-shrink-0">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container px-5">
                    <a class="navbar-brand" href="Student_Home.php">Job Management System - Student</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="Student_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Applied_Job.php">Applied Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Favorite_Job.php">Favourite Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="Student_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo $_SESSION['username'] ?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

            <div class="container px-5">
            

            <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

            <div class="row gx-5 justify-content-center">
            <div class="col-lg-8 col-xl-6">

        <form id="contactForm" method="post" action="Student_ChangePassword.php">

                    <div class="text-center mb-5">
                        <h1 class="fw-bolder" style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)">Reset Password Form</h1>
                        <p class="lead fw-normal text-muted mb-0">Enter your new password.</p>
                    </div>

            <div class="form-floating mb-3"> 
                <input type="password" name="password" class="form-control" placeholder=" " required>
                <label for="password">New Password:</label>
            </div>

            <div class="form-floating mb-3"> 
                <input type="password" name="conform_password" class="form-control" placeholder=" " required>
                <label for="conform_password">Conform Password:</label>
            </div>

            <input type="submit" class="form_button" name="submit_new_password_student" value="Submit"></br>
            <input type="submit" class="form_button btn-secondary" name="back" value="Back" formnovalidate></br></br>
        </form>
    
        </div>
                </div>
                </div>

                <div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                            <div class="h5 mb-2">Chat with us</div>
                            <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                            <div class="h5">Ask the community</div>
                            <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                            <div class="h5">Support center</div>
                            <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                            <div class="h5">Call us</div>
                            <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <!-- Footer-->
        <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

        <script>
            function checkerLogout(){
                var result = confirm('Are you sure you want to logout?');
                if(result == false){
                    event.preventDefault();
                }
            }
        </script>

</body>
</html>