<?php
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/JobProvider_Login_Page.php');
    }

    $sql="SELECT * FROM login_jobprovider WHERE email = '$email'";
    $result=$conn->query($sql);

    if ($result->num_rows > 0) {    
        while($row = $result->fetch_assoc()) {
            //display result
            $username=$row['username'];
            $jobProviderID=$row['jobProviderID'];
        }
    }
    $_SESSION['username'] = $username;
    $_SESSION['jobProviderID'] = $jobProviderID;

    if(isset($_POST['submit'])){
        $jobProviderID2 = $_SESSION['jobProviderID'];
        $title = $_POST['title'];
        $date = date('Y-m-d H:i:s', time()+8*60*60);
        $jobID = $jobProviderID2."_".$title."_".$date;
        $salary1 = $_POST['salary1'];
        $salary2 = $_POST['salary2'];
        $description = $_POST['description'];
        $requirement = $_POST['requirement'];
        $level = $_POST['level'];
        $qualification = $_POST['qualification'];
        $experience = $_POST['experience'];
        $jobType = $_POST['jobType'];
        $specialization = $_POST['specialization'];
        $approveStatus = "Pending";
        $activateStatus = "Activate";
        $deleteStatus = "No";
        $reasonDisapprove = "";
        $reasonDeactivate = "";

        if($salary2 < $salary1){
            echo '<script> alert("Please insert the correct salary.");</script>';
        }else{

            $insert_data = "INSERT INTO job (jobID, jobProviderID, title, salary1, salary2, description, requirement, level, qualification, experience, jobType, specialization, date, approveStatus, activateStatus, deleteStatus, reasonDisapprove, reasonDeactivate) 
            values('$jobID', '$jobProviderID2', '$title', '$salary1', '$salary2', '$description', '$requirement', '$level', '$qualification', '$experience', '$jobType', '$specialization', '$date' , '$approveStatus', '$activateStatus', '$deleteStatus', '$reasonDisapprove', '$reasonDeactivate')";
            
            $data_check = $conn->query($insert_data);
            if($data_check){
                echo '<script> alert("Create Job Successfully"); location.href = "JobProvider_Manage_Job.php" </script>';
            }else{
                $errors = "Failed while inserting data into database! Please make sure the job title cannot be the same with your others created job!!! And cannot include quatation marks!!!";
                echo"<script> alert('$errors')</script>";
            }
        }
        
    }

    if(isset($_POST['back'])){
        echo '<script> location.href = "JobProvider_Manage_Job.php" </script>';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create New Job</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
    width: 100%;
    height:100%;
    }
    h1,h2{
    text-align: center;
    }
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
<link href="../Visitor/css/styles.css" rel="stylesheet" />

</head>

<body class="d-flex flex-column">
<main class="flex-shrink-0">
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job.php">Manage Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job_Apply_Request.php">Apply Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Hire_List.php">Hire List</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="JobProvider_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo  $username?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>Create A New Job</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

</br>

<div class="container">

<form action="JobProvider_Create_Job.php" method="post" enctype="multipart/form-data">
  <div class="mb-3">
    <label for="title" class="form-label"><b>Job Title (Ex: Intern For Software Engineer)</label>
    <input type="text" class="form-control" name="title" required>
  </div>
  <div class="mb-3">
    <label for="salary" class="form-label">Salary</label><br>
    RM
    <input type="number" name="salary1" required> -
    <input type="number" name="salary2" required>
  </div>
  <div class="mb-3">
    <label for="description" class="form-label">Job Descriptions (Ex: Describe the job details and highlight)</label>
    <textarea class="form-control" rows="6" name="description" required></textarea>
  </div>
  <div class="mb-3">
    <label for="requirement" class="form-label">Job Requirements (Ex: Need what skills)</label>
    <textarea class="form-control" rows="6" name="requirement" required></textarea>
  </div>
  <div class="mb-3">
    <label for="level" class="form-label">Job Career Level (Ex: Entry/Senior Executive/Manager)</label>
    <input type="text" class="form-control" name="level" required>
  </div>
  <div class="mb-3">
    <label for="qualification" class="form-label">Need For Qualification (Ex: SPM/STPM/Diploma/Degree)</label>
    <input type="text" class="form-control" name="qualification" required>
  </div>
  <div class="mb-3">
    <label for="experience" class="form-label">Years of Experience</label>
    <input type="text" class="form-control" name="experience" required>
  </div>
  <div class="mb-3">
    <label for="jobType" class="form-label">Job Type</label>
                    <select name="jobType" id="jobType" class="form-select">
                        <option value="Full-Time">Full-Time</option>
                        <option value="Part-Time">Part-Time</option>
                        <option value="Part-Time">Contract</option>
                    </select>
  </div>
  <div class="mb-3">
    <label for="specialization" class="form-label">Job Specializations</label>
                    <select name="specialization" id="specialization" class="form-select">
                    <?php 
                        $sql="SELECT * FROM job_Field";
                        $result=$conn->query($sql);
                        if ($result->num_rows > 0) {    
                            while($row = $result->fetch_assoc()) {
                                //display result
                                $jobFieldName=$row['jobFieldName'];
                                ?>
                                <option value="<?php echo $jobFieldName ?>"><?php echo $jobFieldName ?></option>
                                <?php
                            }
                        }
                    ?>
                    </select>
  </div>

  <button type="submit" class="btn btn-secondary" name="back" formnovalidate>Back</button>
  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>

<br>
<hr>
<div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                    <div class="h5 mb-2">Chat with us</div>
                    <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                    <div class="h5">Ask the community</div>
                    <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                    <div class="h5">Support center</div>
                    <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                    <div class="h5">Call us</div>
                    <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                </div>
            </div>
        </div>

</section>
</main>
<footer class="bg-dark py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
            <div class="col-auto">
                <a class="link-light small" href="#!">Privacy</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Terms</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>

</body>

</html>