<?php 
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];
    $studentID = $_SESSION['studentID'];
    $reason1 = '(The job provider has already deactivate the job.)';
    $reason2 = '(The admin has deactivated the job.)';
    $reason3 = '（The job provider has edited the job. Please wait for admin to approve.）';
    $reason4 = '（The admin has disapproved the job.）';
    $keywords = '';

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/Student_Login_Page.php');
    }

    $sql="select * from favorite_Job left join job on job.jobID=favorite_Job.jobID left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID WHERE studentID = '$studentID'";
    $result=$conn->query($sql);

    if(isset($_POST['search'])){
        $keywords = $_POST['keywords'];
        $sql="select * from favorite_Job left join job on job.jobID=favorite_Job.jobID left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID WHERE studentID = '$studentID' AND (job.jobID LIKE '%$keywords%' OR job.title LIKE '%$keywords%' OR login_jobprovider.company_name LIKE '%$keywords%')";
        $result=$conn->query($sql);
    }

    if(isset($_POST['delete'])){
        $favoriteJobID=$_POST['favoriteJobID'];
        $sql2="DELETE FROM favorite_Job where favoriteJobID='$favoriteJobID'";
        $result2=$conn->query($sql2);

        if($result2){
            echo '<script> alert("Delete Favorite Job Successfully"); location.href = "Student_Favorite_Job.php" </script>';
        }
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Student Favorite Job</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
    width: 100%;
    height:100%;
    }
    h1,h2{
    text-align: center;
    }

    body{
	font-family: sans-serif;
    }

    .table{
        width: 100%;
        border-collapse: collapse;
    }

    .table td,.table th{
    padding:12px 15px;
    border:1px solid #ddd;
    text-align: center;
    font-size:16px;
    }

    .table th{
        background-color: red;
        color:#ffffff;
    }

    .table tbody tr:nth-child(even){
        background-color: #f5f5f5;
    }

    /*responsive*/

    @media(max-width: 500px){
        .table thead{
            display: none;
        }

        .table, .table tbody, .table tr, .table td{
            display: block;
            width: 100%;
        }
        .table tr{
            margin-bottom:15px;
        }
        .table td{
            text-align: right;
            padding-left: 50%;
            text-align: right;
            position: relative;
        }
        .table td::before{
            content: attr(data-label);
            position: absolute;
            left:0;
            width: 50%;
            padding-left:15px;
            font-size:15px;
            font-weight: bold;
            text-align: left;
        }
    }
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
<link href="../Visitor/css/styles.css" rel="stylesheet" />

<!-- Icons-->
<script src="https://kit.fontawesome.com/69fab1ea60.js" crossorigin="anonymous"></script>
</head>

<body class="d-flex flex-column">
<main class="flex-shrink-0">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container px-5">
                    <a class="navbar-brand" href="Student_Home.php">Job Management System - Student</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="Student_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Applied_Job.php">Applied Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Favorite_Job.php">Favourite Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="Student_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo $_SESSION['username'] ?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">


            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>Favorite Job List</b></h2>
                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

</br>

<div class="container">
    

    <div style="padding-bottom: 2px; float: right">
        <form action="Student_Favorite_Job.php" method="post">
            <input type="text" placeholder="Search bar" name="keywords"/>
            <input type="submit" value="Search" name="search" type="button" class="btn btn-warning"/>
        </form>
    </div>

    <table class="table">
     <thead>
     	<tr>
     	    <th style="background-color: purple; color:#ffffff;">Company</th>
            <th style="background-color: purple; color:#ffffff;">Title</th>
            <th style="background-color: purple; color:#ffffff;">Added Time</th>
            <th style="background-color: purple; color:#ffffff;">Available Status</th>
            <th style="background-color: purple; color:#ffffff;">Action</th>
        </tr>
     </thead>
     <tbody>
            <?php
                if ($result->num_rows > 0) {    
                    while($row = $result->fetch_assoc()) {
                        //display result
                        $photo=$row['photo'];
                        $favoriteJobID=$row['favoriteJobID'];
                        $jobID=$row['jobID'];
                        $title=$row['title'];
                        $favoriteDate=$row['favoriteDate'];
                        $company_name=$row['company_name'];
                        $activateStatus=$row['activateStatus'];
                        $deleteStatus =$row['deleteStatus'];
                        $approveStatus = $row['approveStatus'];
            ?>
            
     	  <tr>
                    <td>
                        <img src="../Photo_JobProvider/<?php echo $photo?>" class="img-radius" width="100px" height="80px"><br>
                        <em class="text-muted">		
                            <?php echo $company_name; ?>              
                        </em>
                    </td>
                    <td><b><?php echo $title; ?></b></td>
                    <td><?php echo $favoriteDate; ?></td>
                    <td><?php if($activateStatus == "Deactivate") echo "<span style='color:red;font-weight:bold'><i class='fas fa-window-close'></i> No Available</span><br><em style='font-size:14px;color:grey'>".$reason2; else if($deleteStatus == "Yes") echo "<span style='color:red;font-weight:bold'><i class='fas fa-window-close'></i> No Available</span><br><em style='font-size:14px;color:grey'>".$reason1; else if($approveStatus == "Pending") echo "<span style='color:#ffa500;font-weight:bold'><i class='fas fa-spinner'></i> Pending</span><br><em style='font-size:14px;color:grey'>".$reason3; else if($approveStatus == "Disapprove") echo "<span style='color:red;font-weight:bold'><i class='fas fa-window-close'></i> No Available</span><br><em style='font-size:14px;color:grey'>".$reason4; else echo "<span style='color:green;font-weight:bold'><i class='fas fa-check-circle'></i> Available" ?></td>
                    <td>
                        <a href="Student_Edit_Favorite_Job.php?pid=<?php echo $jobID; ?>" class="btn btn-warning" style="width:100px;margin-bottom:6px">View</a>
                        <form action="Student_Favorite_Job.php" method="post">
                            <input type="hidden" value="<?php echo $favoriteJobID ?>" name="favoriteJobID">
                            <input type="submit" name = "delete" value="Delete" class="btn btn-danger" style="width:100px;margin-bottom:6px" onclick="checker()">
                        </form>
                    </td>
     	  </tr>

            <?php
                    } //end while loop
                }	// end if statement
            ?>

     </tbody>
   </table>

    </div>


</div>
</div>

<div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                    <div class="h5 mb-2">Chat with us</div>
                    <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                    <div class="h5">Ask the community</div>
                    <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                    <div class="h5">Support center</div>
                    <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                    <div class="h5">Call us</div>
                    <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                </div>
            </div>
        </div>

</section>
</main>
<footer class="bg-dark py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
            <div class="col-auto">
                <a class="link-light small" href="#!">Privacy</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Terms</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

<script>
    function checker(){
        var result = confirm('Are you sure you want to delete?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>

</body>

</html>