<?php
    include ('../Connection.php');
    $sender = $_POST['sender'];
    $receiver = $_POST['receiver'];

    $sql="SELECT * from message WHERE (sender = '$sender' AND receiver='$receiver') OR (sender = '$receiver' AND receiver = '$sender') ORDER BY message_date";
    $result=$conn->query($sql);
    if ($result->num_rows > 0) {    
        while($row = $result->fetch_assoc()) {
            $content = $row['content'];
            $message_date = $row['message_date'];
            $sender2 = $row['sender'];

            if($sender == $sender2){
                echo '<span style="float:right;">';
                echo $content;
                echo str_repeat("&nbsp;", 4); 
                echo '<em style="font-size:small">[';
                echo $message_date;
                echo ']</em>';
                echo '</span><br>';
            }else{
                echo '<span style="float:left;">';
                echo '<em style="font-size:small">[';
                echo $message_date;
                echo ']</em>';
                echo '</span>';
                echo str_repeat("&nbsp;", 4); 
                echo $content;
                echo '<br>';
            }
        }
    }
   
?>
