<?php 
session_start();
require "../Connection.php";
$errors = array();
$fetch_pass = '';

if(isset($_POST['login_admin'])){
    $admin_name = $_POST['username'];
    $admin_password = $_POST['password'];

    $sql="SELECT * FROM admin WHERE admin_name = '$admin_name'";
    $result=$conn->query($sql);
    if ($result->num_rows > 0) {    
        while($row = $result->fetch_assoc()) {
            $fetch_pass = $row['admin_password'];
        }
    }

    if(password_verify($admin_password, $fetch_pass)){
        if($admin_name == 'manager'){
            $_SESSION['admin_name'] = $admin_name;
            header('location: ../Admin/Admin_Manager.php');
        }else{
            $_SESSION['admin_name'] = $admin_name;
            header('location: ../Admin/Admin_Home.php');
        }
    }
    else{
        $errors['email'] = "Incorrect username or password!";
    }

}
?>