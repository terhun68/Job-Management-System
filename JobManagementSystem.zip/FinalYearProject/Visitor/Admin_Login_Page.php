<?php
    require_once "Admin_ControlUserData.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Admin Login</title>
    <link rel="stylesheet" type="text/css" href="Admin_Login_Page_CSS.css">
</head>
<body>
    <main class="form_1">
        <form class="form" method="post" action="Admin_Login_Page.php">
            <span class="form_title">Login Form</span></br>
            <span class="form_description">Login with your admin name and password.<span></br></br>

            <?php
                    if(count($errors) > 0){
                        ?>
                        <div class="error">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div><br>
                        <?php
                    }
                    ?>

            <div class="form_div"> 
                <input type="text" name="username" class="form_input" placeholder=" " required>
                <label for="username" class="form_label">Name:</label>
            </div>

            <div class="form_div"> 
                <input type="password" name="password" class="form_input" placeholder=" " required>
                <label for="password" class="form_label">Password:</label>
            </div>

            <input type="submit" class="form_button" name="login_admin" value="Login"></br>

        </form>
    </main>
</body>
</html>