-- --------------------------------------------------------
-- Host:                         localhost
-- Server version:               5.7.24 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Version:             10.2.0.5599
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Dumping database structure for job_management_system
CREATE DATABASE IF NOT EXISTS `job_management_system` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `job_management_system`;

-- Dumping structure for table job_management_system.admin
CREATE TABLE IF NOT EXISTS `admin` (
  `admin_name` varchar(255) DEFAULT NULL,
  `admin_password` varchar(255) DEFAULT NULL,
  `admin_position` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.admin: ~2 rows (approximately)
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` (`admin_name`, `admin_password`, `admin_position`) VALUES
	('manager', '$2y$10$jUTgNGqJHIgCX8TZnr6NU.v8T9VuRSsfFLf8ufA8Y5C6mpIn.MhLu', 'manager'),
	('admin', '$2y$10$xgfdXGqU8V5niA8Q/iGJheZuRkIZsobN8jVO3FBs1rMWYubRSI4/y', 'staff'),
	('admin2', '$2y$10$Co8NY3KKUjqGJU5oZQuzeuiAC6ZoNmg7c6AVFSMbN8/DnhoSwEAJC', 'staff');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;

-- Dumping structure for table job_management_system.conversation
CREATE TABLE IF NOT EXISTS `conversation` (
  `conversationID` int(11) NOT NULL AUTO_INCREMENT,
  `person1` varchar(255) DEFAULT NULL,
  `person2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`conversationID`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.conversation: ~0 rows (approximately)
/*!40000 ALTER TABLE `conversation` DISABLE KEYS */;
INSERT INTO `conversation` (`conversationID`, `person1`, `person2`) VALUES
	(1, 's_jiajun@gmail.com', 'j_apple@gmail.com');
/*!40000 ALTER TABLE `conversation` ENABLE KEYS */;

-- Dumping structure for table job_management_system.favorite_job
CREATE TABLE IF NOT EXISTS `favorite_job` (
  `favoriteJobID` varchar(255) NOT NULL,
  `jobID` varchar(255) DEFAULT NULL,
  `studentID` varchar(255) DEFAULT NULL,
  `favoriteDate` datetime DEFAULT NULL,
  PRIMARY KEY (`favoriteJobID`),
  KEY `jobID` (`jobID`),
  KEY `studentID` (`studentID`),
  CONSTRAINT `favorite_job_ibfk_1` FOREIGN KEY (`jobID`) REFERENCES `job` (`jobID`),
  CONSTRAINT `favorite_job_ibfk_2` FOREIGN KEY (`studentID`) REFERENCES `login_student` (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.favorite_job: ~0 rows (approximately)
/*!40000 ALTER TABLE `favorite_job` DISABLE KEYS */;
INSERT INTO `favorite_job` (`favoriteJobID`, `jobID`, `studentID`, `favoriteDate`) VALUES
	('s_jiajun@gmail.com&j_childcare@gmail.com_Student Care Assistant Teacher_2022-01-13 15:22:51', 'j_childcare@gmail.com_Student Care Assistant Teacher_2022-01-13 15:22:51', 's_jiajun@gmail.com', '2022-01-13 15:36:46');
/*!40000 ALTER TABLE `favorite_job` ENABLE KEYS */;

-- Dumping structure for table job_management_system.feedback
CREATE TABLE IF NOT EXISTS `feedback` (
  `feedbackID` varchar(255) NOT NULL,
  `jobApplyStatusID` varchar(255) DEFAULT NULL,
  `rating` varchar(255) DEFAULT NULL,
  `content` text,
  `feedback_date` datetime DEFAULT NULL,
  `feedback_status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`feedbackID`),
  KEY `jobApplyStatusID` (`jobApplyStatusID`),
  CONSTRAINT `feedback_ibfk_1` FOREIGN KEY (`jobApplyStatusID`) REFERENCES `job_apply_status` (`jobApplyStatusID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.feedback: ~0 rows (approximately)
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` (`feedbackID`, `jobApplyStatusID`, `rating`, `content`, `feedback_date`, `feedback_status`) VALUES
	('f_s_jiajun@gmail.com_j_apple@gmail.com_Senior Manager On App Store_2022-01-13 14:59:51', 's_jiajun@gmail.com_j_apple@gmail.com_Senior Manager On App Store_2022-01-13 14:59:51', '4.8', 'Good job seeker, nice !!!!', '2022-01-14 15:27:38', 'Activate');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;

-- Dumping structure for table job_management_system.job
CREATE TABLE IF NOT EXISTS `job` (
  `jobID` varchar(255) NOT NULL,
  `jobProviderID` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `salary1` double DEFAULT NULL,
  `salary2` double DEFAULT NULL,
  `description` text,
  `requirement` text,
  `level` varchar(255) DEFAULT NULL,
  `qualification` varchar(255) DEFAULT NULL,
  `experience` varchar(255) DEFAULT NULL,
  `jobType` varchar(255) DEFAULT NULL,
  `specialization` varchar(255) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `approveStatus` varchar(255) DEFAULT NULL,
  `activateStatus` varchar(255) DEFAULT NULL,
  `deleteStatus` varchar(255) DEFAULT NULL,
  `reasonDeactivate` varchar(255) DEFAULT NULL,
  `reasonDisapprove` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`jobID`),
  KEY `jobProviderID` (`jobProviderID`),
  CONSTRAINT `job_ibfk_1` FOREIGN KEY (`jobProviderID`) REFERENCES `login_jobprovider` (`jobProviderID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.job: ~4 rows (approximately)
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` (`jobID`, `jobProviderID`, `title`, `salary1`, `salary2`, `description`, `requirement`, `level`, `qualification`, `experience`, `jobType`, `specialization`, `date`, `approveStatus`, `activateStatus`, `deleteStatus`, `reasonDeactivate`, `reasonDisapprove`) VALUES
	('j_apple@gmail.com_Sales for Apple_2022-01-13 15:05:59', 'j_apple@gmail.com', 'Sales for Apple', 3000, 10000, 'Competitive Salary and Bonus Package\r\nEmployee-Friendly Workplace\r\nOutstanding career development opportunities.\r\n\r\nNeed to promote our new apple products.', 'Good communicating skills.\r\nBrave.\r\nPerform market research to understand the various industries', 'Junior Executive', 'Diploma in IT, Bussiness, Marketing', '-', 'Full-Time', 'Sales/ Marketing', '2022-01-13 15:05:59', 'Approve', 'Activate', 'No', '', ''),
	('j_apple@gmail.com_Senior Manager On App Store_2022-01-13 14:59:51', 'j_apple@gmail.com', 'Senior Manager On App Store', 10000, 20000, '1. Innovative and Energetic Workplace with a Growth Mindset\r\n2. Work Life Balance Mindset\r\n3. Teamwork Mindset\r\n\r\nAt Apple, we would like you to love your job so weâ€™ve created a fun working environment with plenty of opportunities to socialise. Weâ€™re also eager to reward you for your hard work and to help you grow. Oh, and we encourage you to have a life outside of work. ', 'At least 10 years in related field.\r\nExperience in communicating with the team.\r\nPublic Speaking.\r\nGood problem solving skills.', 'Senior App Manager', 'Master in IT fields', '10', 'Full-Time', 'Computer/ Information Technology', '2022-01-13 14:59:51', 'Approve', 'Activate', 'No', '', ''),
	('j_apple@gmail.com_Senior Software Engineer in App Store Development_2022-01-13 15:03:12', 'j_apple@gmail.com', 'Senior Software Engineer in App Store Development', 7000, 100000, '1. Innovative and Energetic Workplace with a Growth Mindset\r\n2. Work Life Balance Mindset\r\n3. Teamwork Mindset\r\n\r\nAt Apple, we would like you to love your job so weâ€™ve created a fun working environment with plenty of opportunities to socialise. Weâ€™re also eager to reward you for your hard work and to help you grow. Oh, and we encourage you to have a life outside of work. ', '4 years experience in related fields.\r\nGood communication.\r\nPerfect Teamwork.', 'Senior Software Engineer', 'Degress in IT', '4', 'Full-Time', 'Computer/ Information Technology', '2022-01-13 15:03:12', 'Approve', 'Activate', 'No', '', ''),
	('j_childcare@gmail.com_Kindergarten Teachers_2022-01-13 23:17:56', 'j_childcare@gmail.com', 'Kindergarten Teachers', 3000, 4000, 'Life has endless possibilities.\r\nExperienced and inexperienced teachers / Montessori Dir. who enjoy being the childrens mentor, although we seek the below in you, yet we are still willing to guide you and keep you close to us if we see you are not able to cope. Cos we play as team to achieve breakthrough for children.', 'Patience.\r\nTalent.\r\nTeaching Skill.\r\nLearning Skill.', 'Junior Executive', 'Degree of Education', '2', 'Full-Time', 'Education/ Training', '2022-01-13 23:17:56', 'Pending', 'Activate', 'No', '', ''),
	('j_childcare@gmail.com_Kitchen Helper Cum Cleaner_2022-01-13 15:24:28', 'j_childcare@gmail.com', 'Kitchen Helper Cum Cleaner', 2000, 3000, '-Washing of dishes and utensils\r\n-Washing of catering table cloths & cooking cloth daily\r\n-Cleaning and clearing all rubbish to the collection area daily\r\n-Cleaning and mopping of classrooms, kitchen floor and dining area daily\r\n-Wiping of shelves and tables at the school daily\r\n-Ensure that the classrooms are clean for usage', 'Minimum 1 year of experience in kitchen and school\r\nWorking experience in school setting is desirable\r\nGood communication and interpersonal skills\r\nAble to multi-task and work independently', 'Entry Level', 'Primary/Secondary School/O Level', '-', 'Full-Time', 'All Field', '2022-01-13 15:24:28', 'Approve', 'Activate', 'No', '', ''),
	('j_childcare@gmail.com_Student Care Assistant Teacher_2022-01-13 15:22:51', 'j_childcare@gmail.com', 'Student Care Assistant Teacher', 2000, 4000, 'Career Growth\r\nGreat working culture\r\nBenefits & perks\r\nAssist in implementing the program for the class in accordance with the policies, guidelines, framework and philosophy of the centre. \r\nAssist in guiding primary school children (primary 1 to 6) to ensure completion of daily homework \r\nAssist in keeping accurate records of childrenâ€™s progress and address each childâ€™s educational and developmental needs on an individual basis to the best of your ability.  \r\nAssist in the preparation and upkeeping of teaching resources, arrangement, appearance and learning environment of the classroom. ', 'Diploma in any discipline \r\nExperience in teaching primary school students will be an advantage \r\nAble to guide in doing primary school subjects \r\nPossess good communication and classroom management skills. ', 'Junior Executive', 'Diploma, Advanced/Higher/Graduate Diploma', '1', 'Full-Time', 'Education/ Training', '2022-01-13 16:42:08', 'Approve', 'Activate', 'No', '', '');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;

-- Dumping structure for table job_management_system.job_apply_status
CREATE TABLE IF NOT EXISTS `job_apply_status` (
  `jobApplyStatusID` varchar(255) NOT NULL,
  `jobID` varchar(255) DEFAULT NULL,
  `studentID` varchar(255) DEFAULT NULL,
  `jobApplyStatusDate` datetime DEFAULT NULL,
  `applyStatus` varchar(255) DEFAULT NULL,
  `hireStatus` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`jobApplyStatusID`),
  KEY `jobID` (`jobID`),
  KEY `studentID` (`studentID`),
  CONSTRAINT `job_apply_status_ibfk_1` FOREIGN KEY (`jobID`) REFERENCES `job` (`jobID`),
  CONSTRAINT `job_apply_status_ibfk_2` FOREIGN KEY (`studentID`) REFERENCES `login_student` (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.job_apply_status: ~0 rows (approximately)
/*!40000 ALTER TABLE `job_apply_status` DISABLE KEYS */;
INSERT INTO `job_apply_status` (`jobApplyStatusID`, `jobID`, `studentID`, `jobApplyStatusDate`, `applyStatus`, `hireStatus`) VALUES
	('s_jiajun@gmail.com_j_apple@gmail.com_Senior Manager On App Store_2022-01-13 14:59:51', 'j_apple@gmail.com_Senior Manager On App Store_2022-01-13 14:59:51', 's_jiajun@gmail.com', '2022-01-13 15:36:32', 'Accepted', 'Hire');
/*!40000 ALTER TABLE `job_apply_status` ENABLE KEYS */;

-- Dumping structure for table job_management_system.job_field
CREATE TABLE IF NOT EXISTS `job_field` (
  `jobFieldID` int(11) NOT NULL,
  `jobFieldName` varchar(255) NOT NULL,
  PRIMARY KEY (`jobFieldID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.job_field: ~14 rows (approximately)
/*!40000 ALTER TABLE `job_field` DISABLE KEYS */;
INSERT INTO `job_field` (`jobFieldID`, `jobFieldName`) VALUES
	(1, 'All Field'),
	(2, 'Accounting/ Finance'),
	(3, 'Admin/ Human Resources'),
	(4, 'Sales/ Marketing'),
	(5, 'Arts/ Media/ Communications'),
	(6, 'Services'),
	(7, 'Hotel/ Restaurant'),
	(8, 'Education/ Training'),
	(9, 'Computer/ Information Technology'),
	(10, 'Engineering'),
	(11, 'Manufacturing'),
	(12, 'Building/ Construction'),
	(13, 'Sciences'),
	(14, 'Healthcare'),
	(15, 'Others');
/*!40000 ALTER TABLE `job_field` ENABLE KEYS */;

-- Dumping structure for table job_management_system.login_jobprovider
CREATE TABLE IF NOT EXISTS `login_jobprovider` (
  `jobProviderID` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `certification` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `approved` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `activate` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `overview` text,
  `company_photo1` varchar(255) DEFAULT NULL,
  `company_photo2` varchar(255) DEFAULT NULL,
  `company_photo3` varchar(255) DEFAULT NULL,
  `company_photo4` varchar(255) DEFAULT NULL,
  `company_size` varchar(255) DEFAULT NULL,
  `average_processing_time` varchar(255) DEFAULT NULL,
  `industry` varchar(255) DEFAULT NULL,
  `benefits_others` varchar(255) DEFAULT NULL,
  `permission` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`jobProviderID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.login_jobprovider: ~2 rows (approximately)
/*!40000 ALTER TABLE `login_jobprovider` DISABLE KEYS */;
INSERT INTO `login_jobprovider` (`jobProviderID`, `username`, `password`, `email`, `country`, `state`, `postal_code`, `address`, `phone_no`, `company_name`, `photo`, `certification`, `code`, `status`, `approved`, `time`, `activate`, `reason`, `overview`, `company_photo1`, `company_photo2`, `company_photo3`, `company_photo4`, `company_size`, `average_processing_time`, `industry`, `benefits_others`, `permission`) VALUES
	('j_apple@gmail.com', 'AppleJobSeeker', '$2y$10$q.nOPRFkC1tsdHDDFq5GveZfZfpEwyS2YFZsiYSCtGM/1cK1GfW9C', 'apple@gmail.com', 'Malaysia', 'Johor', '81100', '57, Jalan Apple, Taman Apple Indah', '0134768900', 'Apple', 'apple@gmail.comapple1.png', 'apple@gmail.comapple2.jpeg', '0', 'verified', 'approve', '2022-01-13 14:42:36', 'activate', '', 'Apple Inc. is an American multinational technology company that specializes in consumer electronics, computer software and online services. Apple is the largest information technology company by revenue (totaling $365.8 billion in 2021) and, as of January 2021, it is the worlds most valuable company, the fourth-largest PC vendor by unit sales and fourth-largest smartphone manufacturer.', 'apple@gmail.comapple3.jpeg', 'apple@gmail.comapple4.jpeg', 'apple@gmail.comapple5.jpeg', 'apple@gmail.comapple6.jpeg', '147,000', '3 days', 'IT', 'Got many employees benefits.', 'yes'),
	('j_childcare@gmail.com', 'Child Care HR', '$2y$10$4KrllC.BfAmXdql43nSv6uHTzSeenpq6MlJzfLjHOPZuTIyiKUHfa', 'childcare@gmail.com', 'Malaysia', 'Kuala Lumpur', '43200', '45, Jalan Kuala, Taman Kuala Kuala', '073897890', 'ChildCareLoveYou', 'childcare@gmail.comchildcare1.jpg', 'childcare@gmail.comapple2.jpeg', '0', 'verified', 'approve', '2022-01-13 15:18:31', 'activate', '', 'Founded in 1998, with the goal of â€˜filling the gapsâ€™ that exist in education world-wide, Child Care Love You began as a research institute using research from the areas of Education, Psychology and Neuroscience to better understand how the learning brain grows and develops, and expertise from the world of theatre to understand how to better engage the young learner and â€˜lead the imaginationâ€™.', 'childcare@gmail.comchildcare2.jpg', 'childcare@gmail.comchildcare3.jpeg', 'childcare@gmail.comchildcare4.jpeg', 'childcare@gmail.comchildcare5.jpg', '20', '2 days', 'Education', 'Got free lunch and other benefits.', 'no'),
	('j_google@gmail.com', 'Google', '$2y$10$NOCz0a1BAZlrcuQ6VQF/fORql1EV2pcHyHaD.EicggtNVJ6HR2KRW', 'google@gmail.com', 'Malaysia', 'Johor', '81100', '66, Jalan Google, Taman Google Indah', '078498765', 'Google', 'google@gmail.comgoogle1.jpg', 'google@gmail.comapple2.jpeg', '0', 'verified', 'not_approved', '2022-01-13 23:09:50', 'activate', '', '', '', '', '', '', '', '', '', '', 'no');
/*!40000 ALTER TABLE `login_jobprovider` ENABLE KEYS */;

-- Dumping structure for table job_management_system.login_student
CREATE TABLE IF NOT EXISTS `login_student` (
  `studentID` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `postal_code` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `phone_no` varchar(255) DEFAULT NULL,
  `field` varchar(255) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `cv` varchar(255) DEFAULT NULL,
  `code` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `activate` varchar(255) DEFAULT NULL,
  `reason` varchar(255) DEFAULT NULL,
  `comment` varchar(255) DEFAULT NULL,
  `permission` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`studentID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.login_student: ~1 rows (approximately)
/*!40000 ALTER TABLE `login_student` DISABLE KEYS */;
INSERT INTO `login_student` (`studentID`, `username`, `password`, `email`, `country`, `state`, `postal_code`, `address`, `phone_no`, `field`, `photo`, `cv`, `code`, `status`, `activate`, `reason`, `comment`, `permission`) VALUES
	('s_jiajun@gmail.com', 'jiajun', '$2y$10$o7bRJGI3Yyn06.KlFZss7.JtqfjdrdNj0DkfmX3CenvyL8goFXAR.', 'jiajun@gmail.com', 'Malaysia', 'Johor', '81100', '89, Jalan Jiajun, Taman Austin Jiajun', '0188977890', 'Computer/ Information Technology,Engineering,Sciences', 'jiajun@gmail.comjiajun.jpeg', 'jiajun@gmail.comcv.png', '0', 'verified', 'activate', '', 'I am so handsome.', 'yes');
/*!40000 ALTER TABLE `login_student` ENABLE KEYS */;

-- Dumping structure for table job_management_system.message
CREATE TABLE IF NOT EXISTS `message` (
  `messageID` int(11) NOT NULL AUTO_INCREMENT,
  `sender` varchar(255) DEFAULT NULL,
  `receiver` varchar(255) DEFAULT NULL,
  `content` text,
  `message_date` datetime DEFAULT NULL,
  PRIMARY KEY (`messageID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

-- Dumping data for table job_management_system.message: ~2 rows (approximately)
/*!40000 ALTER TABLE `message` DISABLE KEYS */;
INSERT INTO `message` (`messageID`, `sender`, `receiver`, `content`, `message_date`) VALUES
	(1, 's_jiajun@gmail.com', 'j_apple@gmail.com', 'hi i am jiajun', '2022-01-13 22:27:50'),
	(2, 'j_apple@gmail.com', 's_jiajun@gmail.com', 'hi i am apple job seeker', '2022-01-13 23:03:43');
/*!40000 ALTER TABLE `message` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
