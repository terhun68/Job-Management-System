<?php 
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/JobProvider_Login_Page.php');
    }

    if(isset($_GET['pid'])){//if received pid from other page
        $pid=$_GET['pid'];
        $sql="select * from login_jobprovider where jobProviderID='$pid'";
        $result=$conn->query($sql);

        if($result->num_rows>0){
            while($row = $result->fetch_assoc() ){
            $jobProviderID = $row['jobProviderID'];
            $username = $row['username'];
            $email = $row['email'];
            $country = $row['country'];
            $state = $row['state'];
            $postal_code = $row['postal_code'];
            $address = $row['address'];
            $phone_no = $row['phone_no'];
            $company_name = $row['company_name'];
            $photo = $row['photo'];
            $certification = $row['certification'];
            $overview = $row['overview'];
            $company_photo1 = $row['company_photo1'];
            $company_photo2 = $row['company_photo2'];
            $company_photo3 = $row['company_photo3'];
            $company_photo4 = $row['company_photo4'];
            $company_size = $row['company_size'];
            $average_processing_time  = $row['average_processing_time'];
            $industry  = $row['industry'];
            $benefits_others  = $row['benefits_others'];
            }
        }
    }

    if(isset($_POST['back'])){
        header('location: JobProvider_Search_Profile.php');
    }
?>
<html>
    <head>
        <title>JobProvider Profile</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css" rel="stylesheet">
        <link href="JobProvider_Profile_CSS.css" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../Visitor/css/styles.css" rel="stylesheet" />
        <!-- Feedback system-->
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
        <style>
            body {
            width: 100%;
            height:100%;
            }
            h1,h2{
            text-align: center;
            }
        </style>
    </head>
    
    <body class="d-flex flex-column">
    <main class="flex-shrink-0">
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job.php">Manage Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job_Apply_Request.php">Apply Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Hire_List.php">Hire List</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="JobProvider_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo  $username?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>
            
            <section class="py-5">

            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>JobProvider Information</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

            <br>


            <div class="container-sm">

            <div class="page-content page-container" id="page-content">

            <form action="JobProvider_Check_Profile.php" method="post">
        
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white">
                                <div class="m-b-25"> <img src="../Photo_JobProvider/<?php echo $photo?>" class="img-radius" width="330px" height="340px"> </div>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">JobProvider ID:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $jobProviderID ?></h6>
                                        <input type="hidden" name="jobProviderID" value="<?php echo $jobProviderID; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Username:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $username ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $email ?></h6>
                                        <input type="hidden" name="email" value="<?php echo $email; ?>" id="email1">
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Address:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $address ?>, <?php echo $state ?>, <?php echo $postal_code ?>, <?php echo $country ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Phone No:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $phone_no ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Company Name:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_name ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Certification:</p>
                                        <h6 class="text-muted f-w-400"><a href="../Certification_JobProvider/<?php echo $certification?>"><?php echo $certification?></a></h6>
                                    </div>
                                    
                                </div>

                            </div>
                        </div>

                        <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>

                        <!-- Second paragraph 1st-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Company Overview</h3>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <textarea name="overview" rows="18" cols="68" readonly><?php echo $overview; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Second paragraph 2rd-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Company Photo</h3>
                                <div class="row">
                                    <div class="m-b-25"> <img src="../Company_Photo_JobProvider/<?php echo $company_photo1?>" class="img-radius" width="510px" height="436px" id="image"> </div>
                                </div>
                            </div>
                        </div>

                        <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                        <!-- Third paragraph 1st-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Additional Company Info</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Company Size:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_size ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Industry:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $industry ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Average Processing Time:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $average_processing_time ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Benefits & Others:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $benefits_others ?></h6>
                                    </div>
                                </div>

                                
                            </div>
                        </div>
                        
                        <!-- Third paragraph 2rd-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Feedback</h3>
                                <div class="row">
                                <div class="m-b-25">

                                <div class="table-responsive" id="pagination_data">  
                                </div>  

                                </div>
                                </div>
                            </div>
                        </div>

                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="button">
                                        <input type="submit" class="btn btn-success" name="back" value="Back" style="margin-left:46%" >
                                </div>
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>


                    </div>
                </div>
            </form>
            
            </div>
        </div>
        </div>
        </div>

        <div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                            <div class="h5 mb-2">Chat with us</div>
                            <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                            <div class="h5">Ask the community</div>
                            <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                            <div class="h5">Support center</div>
                            <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                            <div class="h5">Call us</div>
                            <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                        </div>
                    </div>
                </div>

        </section>
    </main>
    <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>


        <script>

        var imageSources = ["../Company_Photo_JobProvider/<?php echo $company_photo2?>","../Company_Photo_JobProvider/<?php echo $company_photo3?>","../Company_Photo_JobProvider/<?php echo $company_photo4?>","../Company_Photo_JobProvider/<?php echo $company_photo1?>"]

        var index = 0;
        setInterval (function(){
        if (index === imageSources.length) {
            index = 0;
        }
        document.getElementById("image").src = imageSources[index];
        index++;
        } , 2000);

        </script>

        <!-- Feedback -->
        <script>  
 $(document).ready(function(){  
      load_data();
      
      function load_data(page,email)  
      {  
           var email = $('#email1').val();
           $.ajax({  
                url:"JobProvider_Pagination.php",  
                method:"POST",  
                data:{page:page,email:email},  
                success:function(data){  
                     $('#pagination_data').html(data);  
                }  
           })  
      }  
      $(document).on('click', '.pagination_link', function(){  
           var page = $(this).attr("id");
           var email = $('#email1').val();
           load_data(page,email);  
      });  
 });  
 </script> 

 <!-- Rating -->
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
        <script>
            $(function () {
                $(".rateYo").rateYo({
                    readOnly: true
                });
            });
        </script>


<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>

    </body>
</html>