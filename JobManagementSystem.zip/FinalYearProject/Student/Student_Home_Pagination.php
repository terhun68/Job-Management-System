<?php
include ('../Connection.php');
session_start();
 $record_per_page = 4;  
 $page = '';  
 $output = ''; 

 $specialization = $_SESSION['specialization'];
 $num_fields = $_SESSION['num_fields'];
 $keywords = $_SESSION['keywords'];
 $expected_salary = $_SESSION['expected_salary'];

if(isset($_POST["page"]))  
 {  
    $page = $_POST["page"];
 }  
 else  
 {  
    $page = 1;
 }
 $start_from = ($page - 1)*$record_per_page;

 for($j = 0; $j < $num_fields; $j++){

    if($expected_salary == ''){
      $sql2="SELECT * FROM job left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID WHERE approveStatus = 'Approve' AND activateStatus = 'Activate' AND deleteStatus = 'No' AND specialization LIKE '%$specialization[$j]%' AND (jobID LIKE '%$keywords%' OR title LIKE '%$keywords%' OR company_name LIKE '%$keywords%') LIMIT $start_from, $record_per_page";
    }else{
      $sql2="SELECT * FROM job left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID WHERE approveStatus = 'Approve' AND activateStatus = 'Activate' AND deleteStatus = 'No' AND specialization LIKE '%$specialization[$j]%' AND (jobID LIKE '%$keywords%' OR title LIKE '%$keywords%' OR company_name LIKE '%$keywords%') AND (salary1 <= $expected_salary AND salary2 >= $expected_salary) LIMIT $start_from, $record_per_page";
    }
    
    $result2=$conn->query($sql2);

    if ($result2->num_rows > 0) {
      while($row = $result2->fetch_assoc()) {
          //display result
          $photo=$row['photo'];
          $jobID=$row['jobID'];
          $title=$row['title'];
          $time=$row['date'];
          $salary1=$row['salary1'];
          $salary2=$row['salary2'];
          $company_name = $row['company_name'];
          $state = $row['state'];
          $description = $row['description'];
          $address = $row['address'];

          echo '

          <section id="cart"> 
          <article class="product">
            <header>
              <a class="remove">
              <img src="../Photo_JobProvider/'; ?><?php echo $photo?> <?php echo ' " ><br>

                <h3>';?><?php echo $company_name; ?><?php echo'</h3>
              </a>
            </header>

            <div class="content">

              <h1>';?><?php echo $title; ?><?php echo'</h1>

              <span style="font-weight:bold">Salary: </span>';?><?php echo 'RM '.$salary1.'-'.$salary2; ?><?php echo'
              <br>
              <span style="font-weight:bold">Place: </span>';?><?php echo $state; ?><?php echo'

            </div>

            <footer class="content">
              <span class="qt-minus">Created On: ';?><?php echo $time; ?><?php echo'</span>

              <h2 class="full-price">
              <a href="Student_Check_Job.php?pid=';?><?php echo $jobID; ?><?php echo' " class="btn btn-warning">Check More</a>
              </h2>

            </footer>
          </article>

          </section><br>


          ';
      }
  }
  if($expected_salary == ''){
    $sql3 = "SELECT * FROM job left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID WHERE approveStatus = 'Approve' AND activateStatus = 'Activate' AND deleteStatus = 'No' AND specialization LIKE '%$specialization[$j]%' AND (jobID LIKE '%$keywords%' OR title LIKE '%$keywords%' OR company_name LIKE '%$keywords%')";  
  }else{
    $sql3 = "SELECT * FROM job left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID WHERE approveStatus = 'Approve' AND activateStatus = 'Activate' AND deleteStatus = 'No' AND specialization LIKE '%$specialization[$j]%' AND (jobID LIKE '%$keywords%' OR title LIKE '%$keywords%' OR company_name LIKE '%$keywords%') AND (salary1 <= $expected_salary AND salary2 >= $expected_salary)";  
  }
$page_result=$conn->query($sql3); 
$total_records = mysqli_num_rows($page_result);  
$total_pages = ceil($total_records/$record_per_page);  
for($i=1; $i<=$total_pages; $i++)  
{  
   $output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".$i."'>".$i."</span>";  
}
$output .= '</div><br /><br />';  

}
echo $output; 

 ?>