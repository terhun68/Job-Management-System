1. This project is using Laragon as database.
2. Set up the job_management_system.sql first. (or can just use the load database function)
	i. Need to create all the tables first. (follow the sequence because got foreign key)
		-admin
		-job_field
		-login_student
		-login_jobprovider
		-job
		-favorite_job
		-job_apply_status
		-feedback
		-message
		-conversation
	ii. Then, insert all of the data inside the database. (follow the sequence)
		-admin
		-job_field
		-login_student
		-login_jobprovider
		-job
		-favorite_job
		-job_apply_status
		-feedback
		-message
		-conversation
3. Open the Visitor folder on the browser.
4. Open the Home.php on the browser.
5. And now can start to use the system.

Sample account:
1. Admin:
	name: admin
	password: B190202C

2. Job Provider:
	email: apple@gmail.com
	password: apple

	email: childcare@gmail.com
	password: childcare

3. Student:
	email: jiajun@gmail.com
	password: jiajun