<?php
    include ('../Connection.php');
    session_start();

    $admin_name = $_SESSION['admin_name'];
    if($admin_name == ''){
        header('location: ../Visitor/Admin_Login_Page.php');
    }

    $sql="select * from login_student WHERE status='verified'";
    $result=$conn->query($sql);
    $selected = "all";

    if(isset($_POST['show_all'])){
        $sql="select * from login_student WHERE status='verified'";
        $result=$conn->query($sql);
        $selected = 'all';
    }

    if(isset($_POST['show_activate'])){
        $sql="select * from login_student WHERE status='verified' AND activate='activate'";
        $result=$conn->query($sql);
        $selected = 'show_activate';
    }

    if(isset($_POST['show_deactivate'])){
        $sql="select * from login_student WHERE status='verified' AND activate='deactivate'";
        $result=$conn->query($sql);
        $selected = 'show_deactivate';
    }

    if(isset($_POST['search_manage_user'])){
        $keywords = $_POST['keywords'];
        $sql="select * from login_student WHERE status='verified' AND (username LIKE '%$keywords%' OR studentID LIKE '%$keywords%' OR email LIKE '%$keywords%')";
        $result=$conn->query($sql);
        $selected = 'all';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Manage User</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
    width: 100%;
    height:100%;
    }
    h1,h2{
    text-align: center;
    }
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
<link href="../Visitor/css/styles.css" rel="stylesheet" />

<!-- Icons-->
<script src="https://kit.fontawesome.com/69fab1ea60.js" crossorigin="anonymous"></script>

</head>

<body class="d-flex flex-column">
<main class="flex-shrink-0">
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:midnightblue">
                <div class="container px-5">
                    <a class="navbar-brand" href="Admin_Home.php">Job Management System - Admin</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="Admin_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Register.php">Register Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Student.php">User</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Approve_Job.php">Job Approve Status</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Job.php">Job Details</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Feedback.php">Feedback</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Job_Field.php">Job Field</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="Admin_Logout.php" style="margin-right: 26px;">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <section class="py-5">

            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>User list (Student)</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

</br>

<div class="container">
    <div style="padding-bottom: 2px; float: left">
        <a href="Admin_Manage_Student.php"><button type="button" class="btn btn-primary">Student</button></a>
        <a href="Admin_Manage_JobProvider.php"><button type="button" class="btn btn-secondary">JobProvider</button></a>
    </div>

    <div style="padding-bottom: 2px; float: right">
        <form action="Admin_Manage_Student.php" method="post">
            <input type="submit" value="All" name="show_all" type="button" <?php if ($selected == "all") echo 'class="btn btn-primary"';else if ($selected == "show_activate") echo 'class="btn btn-secondary"';else if ($selected == "show_deactivate") echo 'class="btn btn-secondary"'; ?>/>
            <input type="submit" value="Activate" name="show_activate" type="button" <?php if ($selected == "all") echo 'class="btn btn-secondary"';else if ($selected == "show_activate") echo 'class="btn btn-primary"';else if ($selected == "show_deactivate") echo 'class="btn btn-secondary"'; ?>/>
            <input type="submit" value="Deactivate" name="show_deactivate" type="button" <?php if ($selected == "all") echo 'class="btn btn-secondary"';else if ($selected == "show_activate") echo 'class="btn btn-secondary"';else if ($selected == "show_deactivate") echo 'class="btn btn-primary"'; ?>/>
            <input type="text" placeholder="Search bar" name="keywords"/>
            <input type="submit" value="Submit" name="search_manage_user" type="button" class="btn btn-warning"/>
        </form>
    </div>

    <table class="table">
    <thead class="table-dark">
        <tr>
        <th scope="col">ID</th>
        <th scope="col">Username</th>
        <th scope="col">Email</th>
        <th scope="col">Activate Status</th>
        <th scope="col">Action</th>
        </tr>
    </thead>
    <tbody>
    <?php
		if ($result->num_rows > 0) {    
			while($row = $result->fetch_assoc()) {
				//display result
				$studentID=$row['studentID'];
				$username=$row['username'];
				$email=$row['email'];
                $activate=$row['activate'];
	?>
        <tr>
            <th scope="row"><?php echo $studentID; ?></th>
            <td><?php echo $username; ?></td>
            <td><?php echo $email; ?></td>
            <td><?php if($activate == 'activate') echo '<span style="color:green;font-weight:bold"><i class="fas fa-check-circle"></i> Activate</span>'; else echo "<span style='color:red;font-weight:bold'><i class='fas fa-window-close'></i> Deactivate</span>"; ?></td>
            <td><a href="Admin_Edit_Student.php?pid=<?php echo $studentID; ?>" class="btn btn-warning">View</a></td>
        </tr>
    <?php
			} //end while loop
		}	// end if statement
	?>
    </tbody>
    </table>
    </div>


</div>
</div>

<div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                    <div class="h5 mb-2">Chat with us</div>
                    <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                    <div class="h5">Ask the community</div>
                    <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                    <div class="h5">Support center</div>
                    <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                    <div class="h5">Call us</div>
                    <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                </div>
            </div>
        </div>

</section>
</main>
<footer class="bg-dark py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
            <div class="col-auto">
                <a class="link-light small" href="#!">Privacy</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Terms</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>
</body>

</html>