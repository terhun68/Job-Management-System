<?php 
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/JobProvider_Login_Page.php');
    }

    $sql="SELECT * FROM login_jobprovider WHERE email = '$email'";
    $result=$conn->query($sql);

    if ($result->num_rows > 0) {    
        while($row = $result->fetch_assoc()) {
            //display result
            $username=$row['username'];
            $jobProviderID = $row['jobProviderID'];
        }
    }
    $_SESSION['username'] = $username;
    $_SESSION['jobProviderID'] = $jobProviderID;
    $jobProviderID2 = $_SESSION['jobProviderID'];

    if(isset($_GET['pid'])){//if received pid from other page
        $pid=$_GET['pid'];
        $sql2="SELECT *, login_Student.username as username2, login_Student.email as email2, login_Student.country as country2, login_Student.state as state2, login_Student.postal_code as postal_code2, login_Student.address as address2, login_Student.phone_no as phone_no2, login_Student.photo as photo2 FROM job_Apply_Status left join job on job_Apply_Status.jobID = job.jobID left join login_jobProvider on job.jobProviderID = login_jobProvider.jobProviderID left join login_Student on job_Apply_Status.studentID = login_Student.studentID WHERE job_apply_status.jobApplyStatusID = '$pid'";
        $result2=$conn->query($sql2);

        if($result2->num_rows>0){
            while($row = $result2->fetch_assoc() ){
                $username2 = $row['username2'];
                $studentID = $row['studentID'];
                $email2 = $row['email2'];
                $country2 = $row['country2'];
                $state2 = $row['state2'];
                $postal_code2 = $row['postal_code2'];
                $address2 = $row['address2'];
                $phone_no2 = $row['phone_no2'];
                $photo2 = $row['photo2'];
                $cv = $row['cv'];

                $jobApplyStatusID = $row['jobApplyStatusID'];

                $jobID = $row['jobID'];
                $title = $row['title'];
                $salary1 = $row['salary1'];
                $salary2 = $row['salary2'];
                $description = $row['description'];
                $requirement = $row['requirement'];
                $level = $row['level'];
                $qualification = $row['qualification'];
                $experience = $row['experience'];
                $jobType = $row['jobType'];
                $specialization = $row['specialization'];
                $date = $row['date'];
            }
        }
    }

    if(isset($_POST['approve'])){
        $jobApplyStatusID = $_POST['jobApplyStatusID'];
        $title = $_POST['title'];
        $email2 = $_POST['email2'];
        $jobID = $_POST['jobID'];

        $sql="UPDATE job_apply_status SET applyStatus = 'Accepted' WHERE jobApplyStatusID = '$jobApplyStatusID'";

        $data_check = $conn->query($sql);
        if($data_check){
            $subject = "Email Job Request Successful Accepted";
            $message = "Your applied job: ".$title." in Job Management System has been successful accepted by the job provider. Please come to check now!!!";
            $sender = "From: B190202C@sc.edu.my";
            if(mail($email2, $subject, $message, $sender)){
                echo '<script> alert("Successful Accept the Job Apply Request"); location.href = "JobProvider_Manage_Apply_Request.php?pid=';
                echo $jobID;
                echo' " </script>';
                exit();
            }else{
                $errors['otp-error'] = "Failed while sending code!";
            }
        }else{
            $errors = "Failed to add into database. Please try again.";
            echo"<script> alert('$errors'); location.href = 'JobProvider_Manage_Apply_Request.php' </script>";
        }
    }

?>
<html>
    <head>
        <title>Apply Request Information</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css" rel="stylesheet">
        <link href="JobProvider_Profile_CSS.css" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../Visitor/css/styles.css" rel="stylesheet" />
        <style>
            body {
            width: 100%;
            height:100%;
            }
            h1,h2{
            text-align: center;
            }
        </style>
    </head>

    <body class="d-flex flex-column">
    <main class="flex-shrink-0">
    <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job.php">Manage Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job_Apply_Request.php">Apply Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Hire_List.php">Hire List</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="JobProvider_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo  $username?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">
                
            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>Apply Request Information</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

            <br>

            <div class="container-sm">

            <div class="page-content page-container" id="page-content">

            <form action="JobProvider_Edit_Apply_Request.php" method="post">
        
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0">
                      
                        <div class="col-sm-12" style="margin-left:10px; margin-right:10px;">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Job Information</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job ID:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $jobID ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job Title:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $title ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Salary:</p>
                                        <h6 class="text-muted f-w-400">RM<?php echo $salary1 ?>-<?php echo $salary2 ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Created Date:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $date ?></h6>
                                    </div>
                                </div>
                        </div>

                        <div class="col-sm-12" style="margin-left:10px; margin-right:10px;">
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="m-b-10 f-w-600">Job Description:</p>
                                        <h6 class="text-muted f-w-400"><textarea style="padding:10px" rows="10" cols="120" readonly><?php echo $description ?></textarea></h6>
                                    </div>
                                </div>
                        </div>

                        <div class="col-sm-12" style="margin-left:10px; margin-right:10px;">
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="m-b-10 f-w-600">Job Requirement:</p>
                                        <h6 class="text-muted f-w-400"><textarea style="padding:10px" rows="10" cols="120" readonly><?php echo $requirement ?></textarea></h6>
                                    </div>
                                </div>
                        </div>

                        <div class="col-sm-12" style="margin-left:10px; margin-right:10px;">
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="m-b-10 f-w-600">Job Experience:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $experience ?></h6>
                                    </div>
                                </div>
                        </div>
                        

                        <div class="col-sm-12" style="margin-left:10px; margin-right:10px;">
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                            <br>
                            <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Additional Information</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Career Level:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $level ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Qualification:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $qualification ?></h6>
                                    </div>
                                </div>
                        </div>

                        <div class="col-sm-12" style="margin-left:10px; margin-right:10px;">
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job Type:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $jobType ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job Specialization:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $specialization ?></h6>
                                    </div>
                                </div>
                        </div>

                        <div class="col-sm-12" style="margin-left:10px; margin-right:10px;">
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                            <br>
                            <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Applier Information</h3>
                        
                    
                    <div class="row m-l-0 m-r-0" style="margin-left:10px; margin-right:10px;">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white">
                                <div class="m-b-25"> <img src="../Photo_Student/<?php echo $photo2?>" class="img-radius" width="280px" height="260px"> </div>
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Student ID:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $studentID ?></h6>
                                        <input type="hidden" name="studentID" value="<?php echo $studentID; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Username:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $username2 ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $email2 ?></h6>
                                        <input type="hidden" name="email" value="<?php echo $email2; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Address:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $address2 ?>, <?php echo $state2 ?>, <?php echo $postal_code2 ?>, <?php echo $country2 ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Phone No:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $phone_no2 ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">CV:</p>
                                        <h6 class="text-muted f-w-400"><a href="../CV_Student/<?php echo $cv?>"><?php echo $cv?></a></h6>
                                    </div>
                                </div>

                            </div>
                        </div>


                    </div>
                </div>

                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <input type="hidden" name="jobID" value="<?php echo $jobID?>">
                                <div class="button" style="text-align:center">
                                    <input type="hidden" value="<?php echo $jobApplyStatusID?>" name="jobApplyStatusID">
                                    <input type="hidden" value="<?php echo $email2?>" name="email2">
                                    <input type="hidden" value="<?php echo $title?>" name="title">
                                    <input type="hidden" value="<?php echo $jobID?>" name="jobID">
                                    <a href="JobProvider_Manage_Apply_Request.php?pid=<?php echo $jobID; ?>" class="btn btn-secondary">Back</a>
                                    <input type="submit" class="btn btn-warning" name="approve" value="Accept">
                                </div>
                            </div><br>
                        </div>
                </form>

            </div>
        </div>
        </div>
        </div>

        <div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                            <div class="h5 mb-2">Chat with us</div>
                            <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                            <div class="h5">Ask the community</div>
                            <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                            <div class="h5">Support center</div>
                            <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                            <div class="h5">Call us</div>
                            <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                        </div>
                    </div>
                </div>

        </section>
    </main>
    <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>


        <script>

        var imageSources = ["../Company_Photo_JobProvider/<?php echo $company_photo2?>","../Company_Photo_JobProvider/<?php echo $company_photo3?>","../Company_Photo_JobProvider/<?php echo $company_photo4?>","../Company_Photo_JobProvider/<?php echo $company_photo1?>"]

        var index = 0;
        setInterval (function(){
        if (index === imageSources.length) {
            index = 0;
        }
        document.getElementById("image").src = imageSources[index];
        index++;
        } , 2000);

        </script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>
    </body>
</html>