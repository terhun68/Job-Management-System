<?php
    include ('../Connection.php');
    session_start();

    $admin_name = $_SESSION['admin_name'];
    if($admin_name == ''){
        header('location: ../Visitor/Admin_Login_Page.php');
    }

    if(isset($_POST['submit'])){
        $admin_name = $_POST['admin_name'];
        $admin_password = $_POST['admin_password'];
        $admin_position = 'staff';
        $encpass = password_hash($admin_password, PASSWORD_BCRYPT);

        $insert_data = "INSERT INTO admin (admin_name, admin_password, admin_position) VALUES ('$admin_name', '$encpass', '$admin_position')";
        $data_check = $conn->query($insert_data);
        if($data_check){
            echo '<script> alert("Create Admin Successfully"); location.href = "Admin_Manager.php" </script>';
        }else{
            $errors = "Failed while inserting data into database! Make sure admin name cannot duplicate.";
            echo"<script> alert('$errors')</script>";
        }
    }

    if(isset($_POST['back'])){
        echo '<script> location.href = "Admin_Manager.php" </script>';
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Create New Admin</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
    width: 100%;
    height:100%;
    }
    h1,h2{
    text-align: center;
    }
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
<link href="../Visitor/css/styles.css" rel="stylesheet" />

</head>

<body class="d-flex flex-column">
<main class="flex-shrink-0">
            <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:midnightblue">
                <div class="container px-5">
                    <a class="navbar-brand" href="Admin_Home.php">Job Management System - Admin</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="Admin_Manager.php">Home</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="Admin_Logout.php" style="margin-right: 26px;">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

</br>
<h2><b>Create A New Admin</b></h2>
<div class="container">

<form action="Admin_Manager_Create_Admin.php" method="post">
    <div class="mb-3">
        <label for="admin_name" class="form-label">Admin Name:</label>
        <input type="text" class="form-control" name="admin_name">
    </div>
  <div class="mb-3">
    <label for="admin_password" class="form-label">Admin Password:</label>
    <input type="text" class="form-control" name="admin_password">
  </div>

  <button type="submit" class="btn btn-secondary" name="back">Back</button>
  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>
<br>
</div>
</div>
</div>

<div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                    <div class="h5 mb-2">Chat with us</div>
                    <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                    <div class="h5">Ask the community</div>
                    <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                    <div class="h5">Support center</div>
                    <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                    <div class="h5">Call us</div>
                    <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                </div>
            </div>
        </div>

</section>
</main>
<footer class="bg-dark py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
            <div class="col-auto">
                <a class="link-light small" href="#!">Privacy</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Terms</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>
</body>

</html>