<?php 
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];
    $errors = array();

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/JobProvider_Login_Page.php');
    }

    $sql="SELECT * FROM login_jobProvider WHERE email = '$email'";
    $result=$conn->query($sql);

    if(isset($_POST['back'])){
        header('location: JobProvider_Profile.php');
    }

    if(isset($_POST['changePassword'])){
        header('location: JobProvider_ChangePassword.php');
    }

    if(isset($_POST['update'])){
        $username = $_POST['username'];
        $country = $_POST['country'];
        $state = $_POST['state'];
        $postal_code = $_POST['postal_code'];
        $address = $_POST['address'];
        $phone_no = $_POST['phone_no'];
        $overview = $_POST['overview'];
        $company_size = $_POST['company_size'];
        $average_processing_time  = $_POST['average_processing_time'];
        $industry  = $_POST['industry'];
        $benefits_others  = $_POST['benefits_others'];
        $email = $_POST['email'];
        $permission = $_POST['permission'];

        $old_photo = $_POST['old_photo'];
        $old_company_photo1 = $_POST['old_company_photo1'];
        $old_company_photo2 = $_POST['old_company_photo2'];
        $old_company_photo3 = $_POST['old_company_photo3'];
        $old_company_photo4 = $_POST['old_company_photo4'];
        
        //check photo
        if(($_FILES['photo']['name'])) {
            $photo=basename($_FILES["photo"]["name"]);
            $photo=$email.$photo;
            $target_dir = "../Photo_JobProvider/";
            $target_file = $target_dir . $email.basename($_FILES["photo"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_POST["update"])) {
                $check = getimagesize($_FILES["photo"]["tmp_name"]);
                if($check !== false) {
                    $uploadOk = 1;
                } else {
                    $errors['photo'] = "Photo field is not an image type.";
                    $uploadOk = 0;
                }
            }

            if ($_FILES["photo"]["size"] > 2000000) {
                $errors['photo'] = " Sorry, your photo is too large.";
                $uploadOk = 0;
            }

            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"){
                $errors['photo'] = " Sorry, only JPG, JPEG, PNG files are allowed for photo field.";
                $uploadOk = 0;
            }

            if ($uploadOk == 0) {
                $errors['photo'] = " Sorry, your photo was not uploaded.";
            } 
            else {
                if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                    
                } else {
                    echo "Sorry, there was an error uploading your photo.";
                }
            }
        }else{
            $photo = $old_photo;
        }

        //check company photo 1
        if(($_FILES['company_photo1']['name'])) {
            $company_photo1=basename($_FILES["company_photo1"]["name"]);
            $company_photo1=$email.$company_photo1;
            $target_dir = "../Company_Photo_JobProvider/";
            $target_file = $target_dir . $email.basename($_FILES["company_photo1"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_POST["update"])) {
                $check = getimagesize($_FILES["company_photo1"]["tmp_name"]);
                if($check !== false) {
                    $uploadOk = 1;
                } else {
                    $errors['company_photo1'] = "Photo field is not an image type.";
                    $uploadOk = 0;
                }
            }

            if ($_FILES["company_photo1"]["size"] > 2000000) {
                $errors['company_photo1'] = " Sorry, your photo is too large.";
                $uploadOk = 0;
            }

            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"){
                $errors['company_photo1'] = " Sorry, only JPG, JPEG, PNG files are allowed for photo field.";
                $uploadOk = 0;
            }

            if ($uploadOk == 0) {
                $errors['company_photo1'] = " Sorry, your photo was not uploaded.";
            } 
            else {
                if (move_uploaded_file($_FILES["company_photo1"]["tmp_name"], $target_file)) {
                    
                } else {
                    echo "Sorry, there was an error uploading your photo.";
                }
            }
        }else{
            $company_photo1 = $old_company_photo1;
        }

        //check company photo 2
        if(($_FILES['company_photo2']['name'])) {
            $company_photo2=basename($_FILES["company_photo2"]["name"]);
            $company_photo2=$email.$company_photo2;
            $target_dir = "../Company_Photo_JobProvider/";
            $target_file = $target_dir . $email.basename($_FILES["company_photo2"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_POST["update"])) {
                $check = getimagesize($_FILES["company_photo2"]["tmp_name"]);
                if($check !== false) {
                    $uploadOk = 1;
                } else {
                    $errors['company_photo2'] = "Photo field is not an image type.";
                    $uploadOk = 0;
                }
            }

            if ($_FILES["company_photo2"]["size"] > 2000000) {
                $errors['company_photo2'] = " Sorry, your photo is too large.";
                $uploadOk = 0;
            }

            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"){
                $errors['company_photo2'] = " Sorry, only JPG, JPEG, PNG files are allowed for photo field.";
                $uploadOk = 0;
            }

            if ($uploadOk == 0) {
                $errors['company_photo2'] = " Sorry, your photo was not uploaded.";
            } 
            else {
                if (move_uploaded_file($_FILES["company_photo2"]["tmp_name"], $target_file)) {
                    
                } else {
                    echo "Sorry, there was an error uploading your photo.";
                }
            }
        }else{
            $company_photo2 = $old_company_photo2;
        }

        //check company photo 3
        if(($_FILES['company_photo3']['name'])) {
            $company_photo3=basename($_FILES["company_photo3"]["name"]);
            $company_photo3=$email.$company_photo3;
            $target_dir = "../Company_Photo_JobProvider/";
            $target_file = $target_dir . $email.basename($_FILES["company_photo3"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_POST["update"])) {
                $check = getimagesize($_FILES["company_photo3"]["tmp_name"]);
                if($check !== false) {
                    $uploadOk = 1;
                } else {
                    $errors['company_photo3'] = "Photo field is not an image type.";
                    $uploadOk = 0;
                }
            }

            if ($_FILES["company_photo3"]["size"] > 2000000) {
                $errors['company_photo3'] = " Sorry, your photo is too large.";
                $uploadOk = 0;
            }

            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"){
                $errors['company_photo3'] = " Sorry, only JPG, JPEG, PNG files are allowed for photo field.";
                $uploadOk = 0;
            }

            if ($uploadOk == 0) {
                $errors['company_photo3'] = " Sorry, your photo was not uploaded.";
            } 
            else {
                if (move_uploaded_file($_FILES["company_photo3"]["tmp_name"], $target_file)) {
                    
                } else {
                    echo "Sorry, there was an error uploading your photo.";
                }
            }
        }else{
            $company_photo3 = $old_company_photo3;
        }

        //check company photo 4
        if(($_FILES['company_photo4']['name'])) {
            $company_photo4=basename($_FILES["company_photo4"]["name"]);
            $company_photo4=$email.$company_photo4;
            $target_dir = "../Company_Photo_JobProvider/";
            $target_file = $target_dir . $email.basename($_FILES["company_photo4"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

            if(isset($_POST["update"])) {
                $check = getimagesize($_FILES["company_photo4"]["tmp_name"]);
                if($check !== false) {
                    $uploadOk = 1;
                } else {
                    $errors['company_photo4'] = "Photo field is not an image type.";
                    $uploadOk = 0;
                }
            }

            if ($_FILES["company_photo4"]["size"] > 2000000) {
                $errors['company_photo4'] = " Sorry, your photo is too large.";
                $uploadOk = 0;
            }

            if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"){
                $errors['company_photo4'] = " Sorry, only JPG, JPEG, PNG files are allowed for photo field.";
                $uploadOk = 0;
            }

            if ($uploadOk == 0) {
                $errors['company_photo4'] = " Sorry, your photo was not uploaded.";
            } 
            else {
                if (move_uploaded_file($_FILES["company_photo4"]["tmp_name"], $target_file)) {
                    
                } else {
                    echo "Sorry, there was an error uploading your photo.";
                }
            }
        }else{
            $company_photo4 = $old_company_photo4;
        }

        //if no error, then update
        if(count($errors) == 0){

            $update_data = "UPDATE login_jobprovider SET username = '$username', country = '$country', state = '$state', postal_code = '$postal_code', address = '$address', phone_no = '$phone_no', overview = '$overview', company_size = '$company_size', average_processing_time = '$average_processing_time', 
            industry = '$industry', benefits_others = '$benefits_others', photo = '$photo', company_photo1 = '$company_photo1', company_photo2 = '$company_photo2', company_photo3 = '$company_photo3', company_photo4 = '$company_photo4', permission = '$permission' WHERE email = '$email'";

            $data_check = $conn->query($update_data);
            if($data_check){
                echo '<script> alert("Update successfully"); location.href = "JobProvider_Profile.php" </script>';
            }else{
                echo "<script> alert('Check your symbols, make sure dont have any quatation marks.'); </script>";
            }
        }else{
            echo '<script>alert("Got error when trying to update the data. Please make sure the photo file type can only be jpg, jpeg and png.")</script>';
        }            
    }
?>
<html>
    <head>
        <title>JobProvider Edit Profile</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css" rel="stylesheet">
        <link href="JobProvider_Profile_CSS.css" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../Visitor/css/styles.css" rel="stylesheet" />
        <style>
            body {
            width: 100%;
            height:100%;
            }
            h1,h2{
            text-align: center;
            }
        </style>
    </head>
        <?php 
            if($result->num_rows>0){
                while($row = $result->fetch_assoc() ){
                    $jobProviderID = $row['jobProviderID'];
                    $username = $row['username'];
                    $email = $row['email'];
                    $country = $row['country'];
                    $state = $row['state'];
                    $postal_code = $row['postal_code'];
                    $address = $row['address'];
                    $phone_no = $row['phone_no'];
                    $company_name = $row['company_name'];
                    $photo = $row['photo'];
                    $certification = $row['certification'];
                    $overview = $row['overview'];
                    $company_photo1 = $row['company_photo1'];
                    $company_photo2 = $row['company_photo2'];
                    $company_photo3 = $row['company_photo3'];
                    $company_photo4 = $row['company_photo4'];
                    $company_size = $row['company_size'];
                    $average_processing_time  = $row['average_processing_time'];
                    $industry  = $row['industry'];
                    $benefits_others  = $row['benefits_others'];
                    $permission = $row['permission'];
        ?>

        <body class="d-flex flex-column">
        <main class="flex-shrink-0">
        <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job.php">Manage Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job_Apply_Request.php">Apply Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Hire_List.php">Hire List</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="JobProvider_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo  $username?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>Edit Information</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

            <br>


            <div class="container-sm">

            <div class="page-content page-container" id="page-content">


            <form action="JobProvider_Edit_Profile.php" method="post" enctype="multipart/form-data">
        
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white">
                                <div class="m-b-25"> <img src="../Photo_JobProvider/<?php echo $photo?>" class="img-radius" width="330px" height="280px" onclick="photoClick()"> </div>
                                <div class="m-b-25">Press the photo to upload your new photo.</div>
                                <input type="file" name="photo" id="photo">
                                <input type="hidden" name="old_photo" value="<?php echo $photo?>">
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">JobProvider ID:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $jobProviderID ?></h6>
                                        <input type="hidden" name="jobProviderID" value="<?php echo $jobProviderID; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Username:</p>
                                        <input type="text" name="username" value="<?php echo $username; ?>" >
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $email ?></h6>
                                        <input type="hidden" name="email" value="<?php echo $email; ?>"  id='email1'>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Company Name:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_name ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Country:</p>
                                        <input type="text" name="country" value="<?php echo $country; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">State:</p>
                                        <input type="text" name="state" value="<?php echo $state; ?>" >
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Postal Code:</p>
                                        <input type="text" name="postal_code" value="<?php echo $postal_code; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Address:</p>
                                        <input type="text" name="address" value="<?php echo $address; ?>" >
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Phone No:</p>
                                        <input type="text" name="phone_no" value="<?php echo $phone_no; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Certification:</p>
                                        <h6 class="text-muted f-w-400" onclick="certificationClick()"><?php echo $certification?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Permission (Others can see your profile and also chat with you.):</p>
                                        <input type="radio" id="yes" name="permission" value="yes" <?php if($permission == 'yes') echo 'checked'; ?> >
                                        <label for="yes">Yes</label><br>
                                        <input type="radio" id="no" name="permission" value="no" <?php if($permission == 'no') echo 'checked'; ?> >
                                        <label for="no">No</label><br>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                            </div>
                        </div>

                        <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                        <!-- Second paragraph 1st-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Overview</h3>
                                <p class="m-b-10 f-w-600">Write something about your company.</p>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <textarea name="overview" rows="16" cols="68"><?php echo $overview; ?></textarea>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Second paragraph 2rd-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Company Photo</h3>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <p class="m-b-10 f-w-600">Make sure all of your photos are corresponded to the format. (JPEG or PNG or JPG ONLY)</p>
                                        <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Choose 1st photo for your company.</p>
                                        <input type="file" name="company_photo1">
                                        <input type="hidden" name="old_company_photo1" value="<?php echo $company_photo1?>">
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Your previous photo:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_photo1?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Choose 2nd photo for your company.</p>
                                        <input type="file" name="company_photo2">
                                        <input type="hidden" name="old_company_photo2" value="<?php echo $company_photo2?>">
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Your previous photo:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_photo2?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Choose 3rd photo for your company.</p>
                                        <input type="file" name="company_photo3">
                                        <input type="hidden" name="old_company_photo3" value="<?php echo $company_photo3?>">
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Your previous photo:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_photo3?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Choose 4th photo for your company.</p>
                                        <input type="file" name="company_photo4">
                                        <input type="hidden" name="old_company_photo4" value="<?php echo $company_photo4?>">
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Your previous photo:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_photo4?></h6>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                        <!-- Third paragraph 1st-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Additional Info</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Company Size:</p>
                                        <input type="text" name="company_size" value="<?php echo $company_size; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Industry:</p>
                                        <input type="text" name="industry" value="<?php echo $industry; ?>" >
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Average Processing Time:</p>
                                        <input type="text" name="average_processing_time" value="<?php echo $average_processing_time; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Benefits & Others:</p>
                                        <input type="text" name="benefits_others" value="<?php echo $benefits_others; ?>" >
                                    </div>
                                </div>

                                
                            </div>
                        </div>
                        
                        <!-- Third paragraph 2rd-->
                        <div class="col-sm-6">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Feedback</h3>
                                <div class="row">

                                <div class="m-b-25">

                                <div class="table-responsive" id="pagination_data">  
                                </div>  
                            </div>
                                    
                                </div>
                            </div>
                        </div>

                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="button">
                                <input type="submit" class="btn btn-secondary" name="back" value="Back" style="margin-left:37%" >
                                    <input type="submit" class="btn btn-warning" name="changePassword" value="ChangePassword">
                                    <input type="submit" class="btn btn-primary" name="update" value="Update">
                                </div>
                            <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>

                    </div>
                </div>
            </form>
            
            </div>
        </div>
        </div>
        </div>

        <div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                            <div class="h5 mb-2">Chat with us</div>
                            <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                            <div class="h5">Ask the community</div>
                            <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                            <div class="h5">Support center</div>
                            <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                            <div class="h5">Call us</div>
                            <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                        </div>
                    </div>
                </div>

        </section>
    </main>
    <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

        <?php
                }
            }
        ?>

        <script>
            function photoClick(){
                document.querySelector('#photo').click();
            }

            function certificationClick(){
                document.querySelector('#certification').click();
            }
        </script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>

<!-- Rating -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
        <script>
            $(function () {
                $(".rateYo").rateYo({
                    readOnly: true
                });
            });
        </script>

<!-- Feedback -->
<script>  
 $(document).ready(function(){  
      load_data();
      
      function load_data(page,email)  
      {  
           var email = $('#email1').val();
           $.ajax({  
                url:"JobProvider_Pagination.php",  
                method:"POST",  
                data:{page:page,email:email},  
                success:function(data){  
                     $('#pagination_data').html(data);  
                }  
           })  
      }  
      $(document).on('click', '.pagination_link', function(){  
           var page = $(this).attr("id");
           var email = $('#email1').val();
           load_data(page,email);  
      });  
 });  
 </script>

    </body>
</html>