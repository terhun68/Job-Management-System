<?php 
include ('../Connection.php');
session_start();
$admin_name = $_SESSION['admin_name'];
if($admin_name == ''){
    header('location: ../Visitor/Admin_Login_Page.php');
}

?>
<html>
    <head>
        <title>Admin Home</title>
        <link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../Visitor/css/styles.css" rel="stylesheet" />
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

        <!-- PieChart for User-->
        <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            <?php
                $total = 0;
                $sql = "SELECT COUNT(*) AS num_student from login_student WHERE status='verified' AND activate='activate'";
                $result=$conn->query($sql);
                if ($result->num_rows > 0) {    
                    while($row = $result->fetch_assoc()) {
                        $num_student = $row['num_student'];
                        $total += $num_student;
                    }
                }

                $sql2 = "SELECT COUNT(*) AS num_jobProvider from login_jobProvider WHERE status='verified' AND activate='activate' AND approved ='approve'";
                $result2=$conn->query($sql2);
                if ($result2->num_rows > 0) {    
                    while($row = $result2->fetch_assoc()) {
                        $num_jobProvider = $row['num_jobProvider'];
                        $total += $num_jobProvider;
                    }
                }
            ?>

            var data = google.visualization.arrayToDataTable([
            ['Category', 'Number of users'],
            ['Student',     <?php echo $num_student; ?>],
            ['Job Provider',      <?php echo $num_jobProvider; ?>]
            ]);

            var options = {
            title: 'Active Users'
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));

            chart.draw(data, options);
        }
        </script>
    </head>
    
    <body class="d-flex flex-column">
    <main class="flex-shrink-0">
            <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:midnightblue">
                <div class="container px-5">
                    <a class="navbar-brand" href="Admin_Home.php">Job Management System - Admin</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="Admin_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Register.php">Register Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Student.php">User</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Approve_Job.php">Job Approve Status</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Job.php">Job Details</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Feedback.php">Feedback</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Job_Field.php">Job Field</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="Admin_Logout.php" style="margin-right: 26px;">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">


                <div style="padding-top:10px;padding-bottom:40px"><hr>
                    <div><span style="font-family:Georgia;font-size:26px">There are total <b><?php echo $total ?></b> active users in this system.</span></div>
                    <div id="piechart" style="width: 100%; height: 400px;"></div>
                </div>


                </div>
                </div>
                </div>

        </section>
    </main>
    <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

        <script>
            function checkerLogout(){
                var result = confirm('Are you sure you want to logout?');
                if(result == false){
                    event.preventDefault();
                }
            }
        </script>

    </body>
</html>