<?php
include ('../Connection.php');

    $content = $_POST['message'];
    $sender = $_POST['sender'];
    $receiver = $_POST['receiver'];
    $message_date = date('Y-m-d H:i:s', time()+8*60*60);

    $sql="INSERT INTO message (sender, receiver, content, message_date) VALUES('$sender','$receiver', '$content', '$message_date')";
    $result=$conn->query($sql);

    $check_got_message = "SELECT * FROM conversation WHERE (person1 = '$sender' AND person2 = '$receiver') OR (person1 = '$receiver' AND person2 = '$sender')";
    $result2=$conn->query($check_got_message);
    if ($result2->num_rows > 0) {  

    }else{
        $insert_conversation = "INSERT INTO conversation (person1, person2) VALUES ('$sender', '$receiver')";
        $result3=$conn->query($insert_conversation);
    }
?>
