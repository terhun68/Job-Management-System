<?php
    
    $conn = new mysqli('127.0.0.1', 'root', '', 'job_management_system');
    if($conn->connect_error) die ("fatal error");
?>