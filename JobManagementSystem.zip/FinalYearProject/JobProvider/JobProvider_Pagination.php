<!-- Rating system-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

<?php  
 //pagination.php  
 include ('../Connection.php');
 session_start();
 $record_per_page = 1;  
 $page = '';  
 $output = ''; 
 $email = '';
 if(isset($_POST["page"]))  
 {  
      $page = $_POST["page"];
      $email = $_POST["email"];  
 }  
 else  
 {  
      $page = 1;
      $email = $_POST["email"];  
 }  
 $start_from = ($page - 1)*$record_per_page;  
 $query = "SELECT *, login_student.username as student_username, login_student.photo as student_photo FROM feedback LEFT JOIN job_apply_status on feedback.jobApplyStatusID = job_apply_status.jobApplyStatusID LEFT JOIN job on job_apply_status.jobID = job.jobID LEFT JOIN login_jobprovider on job.jobProviderID = login_jobprovider.jobProviderID LEFT JOIN login_student on job_apply_status.studentID = login_student.studentID WHERE login_jobprovider.email = '$email' AND feedback.feedback_status = 'Activate' ORDER BY feedback.feedback_date DESC LIMIT $start_from, $record_per_page";  
 $result=$conn->query($query); 
 
 if($result->num_rows>0){
    while($row = $result->fetch_assoc() ){
        $title = $row['title'];
        $content = $row['content'];
        $rating = $row['rating'];
        $student_username = $row['student_username'];
        $feedback_date = $row['feedback_date'];
        $student_photo = $row['student_photo'];
?>
<table class="table">
                                    <tr>
                                        <th>
                                            <img src="../Photo_Student/<?php echo $student_photo?>  "class="img-radius" width="100px" height="80px"><br>
                                            <em class="text-muted">		
                                                <?php echo $student_username; ?>                       
                                            </em>
                                        </th>
                                        <td >
                                            <span class="rateyo" id= "rating"
                                                data-rateyo-rating="<?php echo $rating ?>"
                                                data-rateyo-num-stars="5"
                                                data-rateyo-score="3">
                                            </span><br>
                                            <em class="text-muted">		
                                                <?php echo $content; ?>                       
                                            </em>
                                        </td>
                                        <td>
                                            <span style="font-weight:bold">Job Title:</span><br> <?php echo $title; ?><br>
                                            <span style="font-weight:bold">Submitted at:</span><br> <?php echo $feedback_date; ?>
                                        </td>
                                    </tr>
                                </table>

                                <?php
                                        }
                                    }

 $page_query = "SELECT *, login_student.username as student_username, login_student.photo as student_photo FROM feedback LEFT JOIN job_apply_status on feedback.jobApplyStatusID = job_apply_status.jobApplyStatusID LEFT JOIN job on job_apply_status.jobID = job.jobID LEFT JOIN login_jobprovider on job.jobProviderID = login_jobprovider.jobProviderID LEFT JOIN login_student on job_apply_status.studentID = login_student.studentID WHERE login_jobprovider.email = '$email' AND feedback.feedback_status = 'Activate' ORDER BY feedback.feedback_date DESC";  
 $page_result=$conn->query($page_query); 
 $total_records = mysqli_num_rows($page_result);  
 $total_pages = ceil($total_records/$record_per_page);  
 for($i=1; $i<=$total_pages; $i++)  
 {  
      $output .= "<span class='pagination_link' style='cursor:pointer; padding:6px; border:1px solid #ccc;' id='".$i."'>".$i."</span>";  
 }  
 $output .= '</div><br /><br />';  
 echo $output; 

 
 ?>  
 <!-- Rating-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
        <script>
            $(function () {
                $(".rateYo").rateYo({
                    readOnly: true
                });
            });
        </script>