<html>
    <head>
        <title>Job Management System</title>
    </head>

    <body>
        <div>
            <a href="">Home Page</a>
            <a href="">Search Page</a>
            <a href="Login_Page.php">Login Page</a>
        </div>
    </body>
</html>