<?php 
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];
    $username = $_SESSION['username'];
    $jobProviderID = $_SESSION['jobProviderID'];
    $back_destination = '';

    $keywords = '';

    //check got login or not
    if($email == ''){
      header('location: ../Visitor/JobProvider_Login_Page.php');
    }

    $sql="SELECT * from conversation WHERE person1 = '$jobProviderID' OR person2 = '$jobProviderID'";
    $result=$conn->query($sql);

    if(isset($_POST['search'])){
        $keywords = $_POST['keywords'];
        $sql="SELECT * from conversation WHERE (person1 = '$jobProviderID' AND person2 LIKE '%$keywords%') OR (person2 = '$jobProviderID' AND person1 LIKE '%$keywords%')";
        $result=$conn->query($sql);
    }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>JobProvider Contact List</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
    width: 100%;
    height:100%;
    }
    h1,h2{
    text-align: center;
    }

    body {
  background: #eee;
  margin: 0;
  padding: 0;
  overflow-x: hidden;
}

.clearfix {
  content: "";
  display: table;
  clear: both;  
}

#site-header, #site-footer {
  background: #fff;
}

#site-header {
  margin: 0 0 30px 0;
}

#site-header h1 {
  font-size: 31px;
  font-weight: 300;
  padding: 40px 0;
  position: relative;
  margin: 0;
}

a {
  color: #000;
  text-decoration: none;

  -webkit-transition: color .2s linear;
  -moz-transition: color .2s linear;
  -ms-transition: color .2s linear;
  -o-transition: color .2s linear;
  transition: color .2s linear;
}

a:hover {
  color: #53b5aa;
}

#site-header h1 span {
  color: #53b5aa;
}

#site-header h1 span.last-span {
  background: #fff;
  padding-right: 150px;
  position: absolute;
  left: 217px;

  -webkit-transition: all .2s linear;
  -moz-transition: all .2s linear;
  -ms-transition: all .2s linear;
  -o-transition: all .2s linear;
  transition: all .2s linear;
}

#site-header h1:hover span.last-span, #site-header h1 span.is-open {
  left: 363px;
}

#site-header h1 em {
  font-size: 16px;
  font-style: normal;
  vertical-align: middle;
}

.container {
  font-family: 'Open Sans', sans-serif;
  margin: 0 auto;
  width: 980px;
}

#cart {
  width: 100%;
}

#cart h1 {
  font-weight: 300;
}

#cart a {
  color: grey;
  text-decoration: none;

  -webkit-transition: color .2s linear;
  -moz-transition: color .2s linear;
  -ms-transition: color .2s linear;
  -o-transition: color .2s linear;
  transition: color .2s linear;
}

#cart a:hover {
  color: #000;
}

.product.removed {
  margin-left: 980px !important;
  opacity: 0;
}

.product {
  border: 1px solid #eee;
  margin: 20px 0;
  width: 100%;
  height: 140px;
  position: relative;

  -webkit-transition: margin .2s linear, opacity .2s linear;
  -moz-transition: margin .2s linear, opacity .2s linear;
  -ms-transition: margin .2s linear, opacity .2s linear;
  -o-transition: margin .2s linear, opacity .2s linear;
  transition: margin .2s linear, opacity .2s linear;
}

.product img {
  width: 100%;
  height: 100%;
}

.product header, .product .content {
  background-color: #fff;
  border: 1px solid #ccc;
  border-style: none none solid none;
  float: left;
}

.product header {
  background: #000;
  margin: 0 1% 20px 0;
  overflow: hidden;
  padding: 0;
  position: relative;
  width: 22%;
  height: 140px;
}

.product header:hover img {
  opacity: .7;
}

.product header:hover h3 {
  bottom: 73px;
}

.product header h3 {
  background: #53b5aa;
  color: #fff;
  font-size: 22px;
  font-weight: 300;
  line-height: 49px;
  margin: 0;
  padding: 0 30px;
  position: absolute;
  bottom: -50px;
  right: 0;
  left: 0;

  -webkit-transition: bottom .2s linear;
  -moz-transition: bottom .2s linear;
  -ms-transition: bottom .2s linear;
  -o-transition: bottom .2s linear;
  transition: bottom .2s linear;
}

.remove {
  cursor: pointer;
}

.product .content {
  box-sizing: border-box;
  -moz-box-sizing: border-box;
  height: 140px;
  padding: 0 20px;
  width: 60%;
}

.product h1 {
  color: #53b5aa;
  font-size: 25px;
  font-weight: 300;
  margin: 17px 0 20px 0;
}

.product footer .price {
  background: #fcfcfc;
  float: right;
  font-size: 15px;
  font-weight: 300;
  line-height: 49px;
  margin: 0;
  padding: 0 30px;
}

.product footer .full-price {
  color: #fff;
  float: right;
  font-size: 22px;
  font-weight: 300;
  line-height: 44px;
  margin: 0;
  padding: 0 30px;

}

.qt, .qt-plus, .qt-minus {
  display: block;
  float: left;
}

.qt {
  font-size: 19px;
  line-height: 50px;
  width: 70px;
  text-align: center;
}

.qt-plus, .qt-minus {
  background: #fcfcfc;
  border: none;
  font-size: 20px;
  font-weight: 300;
  height: 100%;
  padding: 0 20px;
  -webkit-transition: background .2s linear;
  -moz-transition: background .2s linear;
  -ms-transition: background .2s linear;
  -o-transition: background .2s linear;
  transition: background .2s linear;
}


.qt-plus {
  line-height: 50px;
}

.qt-minus {
  line-height: 47px;
}

#site-footer {
  margin: 30px 0 0 0;
}

#site-footer {
  padding: 40px;
}

#site-footer h1 {
  background: #fcfcfc;
  border: 1px solid #ccc;
  border-style: none none solid none;
  font-size: 24px;
  font-weight: 300;
  margin: 0 0 7px 0;
  padding: 14px 40px;
  text-align: center;
}

#site-footer h2 {
  font-size: 24px;
  font-weight: 300;
  margin: 10px 0 0 0;
}

#site-footer h3 {
  font-size: 19px;
  font-weight: 300;
  margin: 15px 0;
}

.left {
  float: left;
}

.right {
  float: right;
}

.btn:hover {
  color: #fff;
  background: #429188;
}

.type {
  background: #fcfcfc;
  font-size: 13px;
  padding: 10px 16px;
  left: 100%;
}

.type, .color {
  border: 1px solid #ccc;
  border-style: none none solid none;
  position: absolute;
}

.color {
  width: 40px;
  height: 40px;
  right: -40px;
}

.red {
  background: #cb5a5e;
}

.yellow {
  background: #f1c40f;
}

.blue {
  background: #3598dc;
}

.minused {
  margin: 0 50px 0 0 !important;
}

.added {
  margin: 0 -50px 0 0 !important;
}
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
<link href="../Visitor/css/styles.css" rel="stylesheet" />

<!-- Icons-->
<script src="https://kit.fontawesome.com/69fab1ea60.js" crossorigin="anonymous"></script>

</head>

<body class="d-flex flex-column">
<main class="flex-shrink-0">
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job.php">Manage Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job_Apply_Request.php">Apply Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Hire_List.php">Hire List</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="JobProvider_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo  $username?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>Contact List - JobProvider</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

</br>

<div class="container">

    <div style="float:left">
        <a href="JobProvider_Contact_List.php" class="btn btn-primary">Go Student <i class="fas fa-chevron-right"></i></a>
    </div>

    <div style="padding-bottom: 2px; float: right">
        <form action="JobProvider_Contact_List_JobProvider.php" method="post">
            <input type="text" placeholder="Search bar" name="keywords"/>
            <input type="submit" value="Search" name="search" type="button" class="btn btn-warning"/>
        </form>
    </div><br>

    <?php
            if ($result->num_rows > 0) {    
                while($row = $result->fetch_assoc()) {
                    //display result
                    $person1=$row['person1'];
                    $person2=$row['person2'];

                    if($jobProviderID == $person1){//select receiver

                        $select_jobProvider="SELECT * from login_jobProvider WHERE jobProviderID = '$person2'";
                        $result_jobProvider=$conn->query($select_jobProvider);
                        if ($result_jobProvider->num_rows > 0) {    
                            while($row = $result_jobProvider->fetch_assoc()) {
                                $photo=$row['photo'];
                                $jobProviderID=$row['jobProviderID'];
                                $username=$row['username'];
                                $email=$row['email'];

                                echo '
                                
    <section id="cart"> 
      <article class="product">
        <header>
          <a class="remove">
          <img src="../Photo_JobProvider/'; ?><?php echo $photo?> <?php echo ' " ><br>

            <h3>';?><?php echo $email; ?><?php echo'</h3>
          </a>
        </header>

        <div class="content">

          <h1 style="margin-top:50px;font-size:40px;font-family:Fantasy">';?><?php echo $username; ?><?php echo'</h1>

        </div>

          <a href="JobProvider_Contact.php?pid4=';?><?php echo $jobProviderID; ?><?php echo' " class="btn btn-success content" style="color:black;width:15%;background-color:green;padding-top:20px;font-size:30px;font-family:Fantasy;margin-left:22px"><i class="far fa-comments fa-2x"></i><br>Contact</a>

      </article>

    </section>
                                
                                ';
                            }
                        }

                    }else if($jobProviderID == $person2){

                        $select_jobProvider="SELECT * from login_jobProvider WHERE jobProviderID = '$person1'";
                        $result_jobProvider=$conn->query($select_jobProvider);
                        if ($result_jobProvider->num_rows > 0) {    
                            while($row = $result_jobProvider->fetch_assoc()) {
                                $photo=$row['photo'];
                                $jobProviderID=$row['jobProviderID'];
                                $username=$row['username'];
                                $email=$row['email'];
                                
                                echo '
                                
                                <section id="cart"> 
                                <article class="product">
                                  <header>
                                    <a class="remove">
                                    <img src="../Photo_JobProvider/'; ?><?php echo $photo?> <?php echo ' " ><br>
                          
                                      <h3>';?><?php echo $email; ?><?php echo'</h3>
                                    </a>
                                  </header>
                          
                                  <div class="content">
                          
                                    <h1 style="margin-top:50px;font-size:40px;font-family:Fantasy">';?><?php echo $username; ?><?php echo'</h1>
                          
                                  </div>
                          
                                    <a href="JobProvider_Contact.php?pid4=';?><?php echo $jobProviderID; ?><?php echo' " class="btn btn-success content" style="color:black;width:15%;background-color:green;padding-top:20px;font-size:30px;font-family:Fantasy;margin-left:22px"><i class="far fa-comments fa-2x"></i><br>Contact</a>
                          
                                </article>
                          
                              </section>
                                
                                ';

                            }
                        }
                    }
                } //end while loop
            }	// end if statement
        ?>

    </div>


</div>
</div>

<div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                    <div class="h5 mb-2">Chat with us</div>
                    <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                    <div class="h5">Ask the community</div>
                    <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                    <div class="h5">Support center</div>
                    <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                    <div class="h5">Call us</div>
                    <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                </div>
            </div>
        </div>

</section>
</main>
<footer class="bg-dark py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
            <div class="col-auto">
                <a class="link-light small" href="#!">Privacy</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Terms</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

<script>
    function checker(){
        var result = confirm('Are you sure?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>

</body>

</html>