<?php 
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/JobProvider_Login_Page.php');
    }

    $sql="SELECT * FROM login_jobprovider WHERE email = '$email'";
    $result=$conn->query($sql);

    if ($result->num_rows > 0) {    
        while($row = $result->fetch_assoc()) {
            //display result
            $username=$row['username'];
            $jobProviderID=$row['jobProviderID'];
        }
    }
    $_SESSION['username'] = $username;
    $_SESSION['jobProviderID'] = $jobProviderID;
              
?>
<html>
    <head>
        <title>JobProvider Home</title>
        <link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../Visitor/css/styles.css" rel="stylesheet" />

        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

        <style>
            .table{
                width: 100%;
                border-collapse: collapse;
            }

            .table td,.table th{
            padding:4px 6px;
            border:1px solid #ddd;
            text-align: center;
            font-size:16px;
            }

            .table th{
                background-color: darkblue;
                color:#ffffff;
            }

            .table tbody tr:nth-child(even){
                background-color: #f5f5f5;
            }
            ul{
                list-style-type: square;
            }
        </style>

        <!-- PieChart for Applier-->
        <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            <?php
                $sql = "SELECT DISTINCT jobID,title FROM job WHERE jobProviderID = '$jobProviderID' AND approveStatus ='Approve' AND activateStatus = 'Activate' AND deleteStatus = 'No'";
                $result=$conn->query($sql);
                $i = 0;
                $j = 0;
                $total = 0;

                if ($result->num_rows > 0) {    
                    while($row = $result->fetch_assoc()) {
                        //display got many jobs
                        $jobID[$i] = $row['jobID'];
                        $name[$i] = $row['title'];

                        //display the number of student applied
                        $sql2 = "SELECT COUNT(*) AS num FROM job_apply_status WHERE jobID = '$jobID[$i]'";
                        $result2=$conn->query($sql2);
                        if ($result2->num_rows > 0) {    
                            while($row = $result2->fetch_assoc()) {
                                $num[$i] = $row['num'];
                                $total +=  $num[$i];

                                if($num[$i] == 0){
                                    $no_applier[$j] = $name[$i];
                                    $j++;
                                }
                            }
                        }

                        $i++;
                    }
                }
            ?>

            var data = google.visualization.arrayToDataTable([
            ['Job Title', 'Number of Appliers'],
            <?php
                for($k = 0; $k < $i; $k++){
                    echo "['".$name[$k]."',".$num[$k]."],";
                }
            ?>

            ]);

            var options = {
                title: 'Number of Each Job Applier'
            };

            var chart = new google.visualization.PieChart(document.getElementById('piechart'));

            chart.draw(data, options);
        }
        </script>

        <!-- PieChart for JobProvider Accept the Applier-->

        <script type="text/javascript">
        google.charts.load('current', {'packages':['corechart']});
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            <?php
                $sql = "SELECT DISTINCT jobID,title FROM job WHERE jobProviderID = '$jobProviderID' AND approveStatus ='Approve' AND activateStatus = 'Activate' AND deleteStatus = 'No'";
                $result=$conn->query($sql);
                $i = 0;
                $total2 = 0;

                if ($result->num_rows > 0) {    
                    while($row = $result->fetch_assoc()) {
                        //display got many jobs
                        $jobID[$i] = $row['jobID'];
                        $name[$i] = $row['title'];

                        //display the number of student applied
                        $sql2 = "SELECT COUNT(*) AS num FROM job_apply_status WHERE jobID = '$jobID[$i]' AND applyStatus = 'Accepted'";
                        $result2=$conn->query($sql2);
                        if ($result2->num_rows > 0) {    
                            while($row = $result2->fetch_assoc()) {
                                $num[$i] = $row['num'];
                                $total2 +=  $num[$i];
                            }
                        }

                        $i++;
                    }
                }
            ?>

                var data = google.visualization.arrayToDataTable([
                ['Job Title', 'Number of Appliers'],
                <?php
                    for($k = 0; $k < $i; $k++){
                        echo "['".$name[$k]."',".$num[$k]."],";
                    }
                ?>

                ]);

                var options = {
                    title: 'Number of Each Job Accepter'
                };

                var chart = new google.visualization.PieChart(document.getElementById('piechart2'));

                chart.draw(data, options);
            }
        </script>
        
    </head>
    <body class="d-flex flex-column">
    <main class="flex-shrink-0">
            <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job.php">Manage Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job_Apply_Request.php">Apply Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Hire_List.php">Hire List</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="JobProvider_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo  $username?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

                <div>
                    <h1 style="font-family:Franklin Gothic Medium">Important Notice!!!</h1>
                    <ul>
                        <li><a style="font-size:20px">Please make sure that you have insert all of the information of your profile after you first time login into this system.</a></li>
                    </ul>
                </div>

                <div style="padding-top:10px;"><hr>
                    <div><span style="font-family:Georgia;font-size:26px">There are total <b><?php echo $total ?></b> appliers have applied the jobs.</span></div>
                    <div id="piechart" style="width: 100%; height: 400px;"></div>
                </div>

                <span style="font-family:Georgia;font-size:26px">The jobs that have no applier yet.</span>

                <div style="text-align:left">
                    <table class="table" style="width:50%;text-align:left">
                    <thead>
                        <tr>
                            <th style="background-color: darkblue; color:#ffffff;">No.</th>
                            <th style="background-color: darkblue; color:#ffffff;">Title</th>
                        </tr>
                            <?php 
                                for($a=0;$a<$j;$a++){
                                    $b = $a+1;
                                    echo '<tr><td><b>'.$b.'</b></td>';
                                    echo '<td><b>'.$no_applier[$a].'</b></td></tr>';
                                }
                            ?>
                    </thead>
                    </table>
                </div>
                                
                
                <div style="padding-top:10px;padding-bottom:40px"><hr>
                    <div><span style="font-family:Georgia;font-size:26px">There are total <b><?php echo $total2 ?></b> appliers have been accepted for the futher interview.</span></div>
                    <div id="piechart2" style="width: 100%; height: 400px;"></div>
                </div>

                </div>
                </div>
                </div>

        </section>
    </main>
    <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

        <script>
            function checkerLogout(){
                var result = confirm('Are you sure you want to logout?');
                if(result == false){
                    event.preventDefault();
                }
            }
        </script>

    </body>
</html>