<?php
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];
    $username = $_SESSION['username'];
    $back_destination = '';

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/JobProvider_Login_Page.php');
    }

    $jobApplyStatusID = '';
    if(isset($_GET['pid'])){//if received pid from other page

        $back_destination = '1';
        $jobApplyStatusID=$_GET['pid'];
        $sql="select *, login_student.username as student_username, login_jobprovider.username as jobProvider_username from job_apply_status left join job on job.jobID=job_apply_status.jobID left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID left join login_student on job_apply_status.studentID = login_student.studentID WHERE jobApplyStatusID = '$jobApplyStatusID'";
        $result=$conn->query($sql);
        if($result->num_rows>0){
            while($row = $result->fetch_assoc() ){
                $student_username = $row['student_username'];
                $jobProvider_username = $row['jobProvider_username'];
                $jobID = $row['jobID'];
                $studentID = $row['studentID'];
                $jobProviderID = $row['jobProviderID'];
            }
        }
    }

    if(isset($_GET['pid2'])){//if received pid from other page

        $back_destination = '2';
        $studentID2=$_GET['pid2'];
        $sql1="select *, login_jobProvider.username as jobProvider_username from login_jobProvider WHERE email = '$email'";
        $result1=$conn->query($sql1);
        if($result1->num_rows>0){
            while($row = $result1->fetch_assoc() ){
                $jobProvider_username = $row['jobProvider_username'];
                $jobProviderID = $row['jobProviderID'];
            }
        }

        $sql2="select *, login_student.username as student_username from login_student WHERE studentID = '$studentID2'";
        $result2=$conn->query($sql2);
        if($result2->num_rows>0){
            while($row = $result2->fetch_assoc() ){
                $student_username = $row['student_username'];
                $studentID = $row['studentID'];
            }
        }
    }

    if(isset($_GET['pid3'])){//if received pid from other page

        $back_destination = '2';
        $jobProviderID2=$_GET['pid3'];
        $sql1="select *, login_jobProvider.username as jobProvider_username from login_jobProvider WHERE email = '$email'";
        $result1=$conn->query($sql1);
        if($result1->num_rows>0){
            while($row = $result1->fetch_assoc() ){
                $jobProvider_username = $row['jobProvider_username'];
                $jobProviderID = $row['jobProviderID'];
            }
        }

        $sql2="select *, login_jobProvider.username as jobProvider_username from login_jobProvider WHERE jobProviderID = '$jobProviderID2'";
        $result2=$conn->query($sql2);
        if($result2->num_rows>0){
            while($row = $result2->fetch_assoc() ){
                $student_username = $row['jobProvider_username'];
                $studentID = $row['jobProviderID'];
            }
        }
    }

    if(isset($_GET['pid4'])){//if received pid from other page //Get from jobprovider contact list jobprovider, show jobprovider

        $back_destination = '3';
        $jobProviderID2=$_GET['pid4'];
        $sql1="select *, login_jobProvider.username as jobProvider_username from login_jobProvider WHERE email = '$email'";
        $result1=$conn->query($sql1);
        if($result1->num_rows>0){
            while($row = $result1->fetch_assoc() ){
                $jobProvider_username = $row['jobProvider_username'];
                $jobProviderID = $row['jobProviderID'];
            }
        }

        $sql2="select *, login_jobProvider.username as jobProvider_username from login_jobProvider WHERE jobProviderID = '$jobProviderID2'";
        $result2=$conn->query($sql2);
        if($result2->num_rows>0){
            while($row = $result2->fetch_assoc() ){
                $student_username = $row['jobProvider_username'];
                $studentID = $row['jobProviderID'];
            }
        }
    }

    if(isset($_GET['pid5'])){//if received pid from other page //Get from jobprovider contact list, show student

        $back_destination = '4';
        $studentID2=$_GET['pid5'];
        $sql1="select *, login_jobProvider.username as jobProvider_username from login_jobProvider WHERE email = '$email'";
        $result1=$conn->query($sql1);
        if($result1->num_rows>0){
            while($row = $result1->fetch_assoc() ){
                $jobProvider_username = $row['jobProvider_username'];
                $jobProviderID = $row['jobProviderID'];
            }
        }

        $sql2="select *, login_student.username as student_username from login_student WHERE studentID = '$studentID2'";
        $result2=$conn->query($sql2);
        if($result2->num_rows>0){
            while($row = $result2->fetch_assoc() ){
                $student_username = $row['student_username'];
                $studentID = $row['studentID'];
            }
        }
    }

    if(isset($_POST['back'])){
        $back_destination=$_POST['back_destination'];
        $jobID = $_POST['jobID'];

        if($back_destination == '1'){
            echo '<script> location.href = "JobProvider_Manage_Accepted_Request.php?pid=';
            echo $jobID;
            echo' " </script>';
        }
        else if($back_destination == '2'){
            echo '<script> location.href = "JobProvider_Search_Profile.php" </script>';
        }
        else if($back_destination == '3'){
            echo '<script> location.href = "JobProvider_Contact_List_JobProvider.php" </script>';
        }
        else if($back_destination == '4'){
            echo '<script> location.href = "JobProvider_Contact_List.php" </script>';
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Job Provider Contact</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
    width: 100%;
    height:100%;
    }
    h1,h2{
    text-align: center;
    }
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
<link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
<link href="../Visitor/css/styles.css" rel="stylesheet" />

<!-- Rating system-->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

<!-- Send Message-->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://code.jquery.com/jquery-3.6.0.js"></script>

<!-- Icons-->
<script src="https://kit.fontawesome.com/69fab1ea60.js" crossorigin="anonymous"></script>

<script>
    function chk(){
        var message = $('#message').val();
        var sender = $('#sender').val();
        var receiver = $('#receiver').val();

        $.ajax({
            method: "post",
            url: "JobProvider_Send_Message.php",
            data:{message:message,sender:sender,receiver:receiver},
            success:function(data){
                $('#message').val("");
            }
            });
        return false;
    };
</script>

</head>

<body class="d-flex flex-column">
<main class="flex-shrink-0">
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job.php">Manage Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Manage_Job_Apply_Request.php">Apply Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Hire_List.php">Hire List</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="JobProvider_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo  $username?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

</br>
<h2><b>Contact</b></h2>
<div class="container">
<hr>

<div>
    <h3>Chat With: <?php echo $student_username ?></h3>
</div>

<div style="overflow:auto; height:400px;width:80%;margin:auto; padding:10px;display:flex; flex-direction:column-reverse;background-size:cover;background:#f5f5f5;">
    <div id="load_message"></div>
</div>
<br>

<form>
<div style="text-align:center">
    <input type="text"  name="message" id="message" placeholder="Type Your Message Here..." size="60" style="padding-bottom:6px">
    <input type="hidden" class="form-control" name="sender" id="sender" value="<?php echo $jobProviderID ?>">
    <input type="hidden" class="form-control" name="receiver" id="receiver" value="<?php echo $studentID ?>">
    <button type="submit"  name="send" value="Send" onclick="return chk()" class="btn btn-primary">Send <i class="fas fa-paper-plane"></i></button>
</div>
</form>

<form action="JobProvider_Contact.php" method="post">
  <input type="hidden" class="form-control" name="jobApplyStatusID" value="<?php echo $jobApplyStatusID ?>">
  <input type="hidden" class="form-control" name="jobID" value="<?php echo $jobID ?>">
  <input type="hidden" class="form-control" name="back_destination" value="<?php echo $back_destination ?>">
  <button type="submit" class="btn btn-secondary" name="back"><i class="fas fa-chevron-left"></i> Back</button>
</form>
<br>
</div>
</div>
</div>

<div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                    <div class="h5 mb-2">Chat with us</div>
                    <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                    <div class="h5">Ask the community</div>
                    <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                    <div class="h5">Support center</div>
                    <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                    <div class="h5">Call us</div>
                    <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                </div>
            </div>
        </div>

</section>
</main>
<footer class="bg-dark py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
            <div class="col-auto">
                <a class="link-light small" href="#!">Privacy</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Terms</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

<!-- Rating-->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
 
<<script>
    $(document).ready(function(){
        setInterval(function(){
            var sender = $('#sender').val();
            var receiver = $('#receiver').val();
            $('#load_message').load("JobProvider_Fetch_Message.php",{sender:sender,receiver:receiver});
        }, 1000);
    });
</script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>
</body>

</html>