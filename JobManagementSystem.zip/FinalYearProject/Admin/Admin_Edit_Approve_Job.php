<?php
    include ('../Connection.php');
    session_start();

    $admin_name = $_SESSION['admin_name'];
    if($admin_name == ''){
        header('location: ../Visitor/Admin_Login_Page.php');
    }

    if(isset($_GET['pid'])){//if received pid from other page
        $pid=$_GET['pid'];
        $sql="SELECT * FROM job left join login_jobprovider on job.jobProviderID=login_jobprovider.jobProviderID where jobID='$pid'";
        $result=$conn->query($sql);
    }

    if(isset($_POST['Back'])){
        echo '<script> location.href = "Admin_Approve_Job.php" </script>';
    }

    if(isset($_POST['Approve'])){
        $jobProviderID = $_POST['jobProviderID'];
        $email = $_POST['email'];
        $jobID = $_POST['jobID'];
        $title = $_POST['title'];
        $jobTitle = $title."(".$jobID.")";
        $reasonDisapprove = $_POST['reasonDisapprove'];
        $sql="UPDATE job set approveStatus = 'Approve', reasonDisapprove = '$reasonDisapprove' WHERE jobID='$jobID'";
        $result=$conn->query($sql);

        if($result){
            $subject = "Email Job Successful Approved";
            $message = "Your job: ".$jobTitle." in Job Management System has been successful approved by the admin. Please come to check now!!!";
            $sender = "From: B190202C@sc.edu.my";
            if(mail($email, $subject, $message, $sender)){
                echo '<script> alert("Approve Job Successfully"); location.href = "Admin_Approve_Job.php" </script>';
                exit();
            }else{
                $errors['otp-error'] = "Failed while sending code!";
            }
        }else{
            $errors['db-error'] = "Failed while inserting data into database!";
        }
    }

    if(isset($_POST['Disapprove'])){
        $jobProviderID = $_POST['jobProviderID'];
        $email = $_POST['email'];
        $jobID = $_POST['jobID'];
        $title = $_POST['title'];
        $jobTitle = $title."(".$jobID.")";
        $reasonDisapprove = $_POST['reasonDisapprove'];
        $sql="UPDATE job set approveStatus = 'Disapprove', reasonDisapprove = '$reasonDisapprove' WHERE jobID='$jobID'";
        $result=$conn->query($sql);

        if($result){
            $subject = "Email Job Disapprove";
            $message = "Your job: ".$jobTitle." in Job Management System has been disapproved by the admin. Reason: ".$reasonDisapprove.". Please contact us for more details!!!";
            $sender = "From: B190202C@sc.edu.my";
            if(mail($email, $subject, $message, $sender)){
                echo '<script> alert("Disapprove Job Successfully"); location.href = "Admin_Approve_Job.php" </script>';
                exit();
            }else{
                $errors['otp-error'] = "Failed while sending code!";
            }
        }else{
            $errors['db-error'] = "Failed while inserting data into database!";
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Edit The Job</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
    body {
    width: 100%;
    height:100%;
    }
    h1,h2{
    text-align: center;
    }
    </style>
    <!-- CSS only -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">

<!-- slow Bootstrap-->
<!-- <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet"> -->
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css" rel="stylesheet">

<link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
<link href="../Visitor/css/styles.css" rel="stylesheet" />

</head>

<body class="d-flex flex-column">
<main class="flex-shrink-0">
<nav class="navbar navbar-expand-lg navbar-dark" style="background-color:midnightblue">
                <div class="container px-5">
                    <a class="navbar-brand" href="Admin_Home.php">Job Management System - Admin</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="Admin_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Register.php">Register Request</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Student.php">User</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Approve_Job.php">Job Approve Status</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Job.php">Job Details</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Feedback.php">Feedback</a></li>
                            <li class="nav-item"><a class="nav-link" href="Admin_Manage_Job_Field.php">Job Field</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="Admin_Logout.php" style="margin-right: 26px;">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>Job Information</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

        <div class="container-sm">
        
<div class="page-content page-container" id="page-content">


<form action="Admin_Edit_Approve_Job.php" method="post">
    <?php
            if($result->num_rows>0){
                while($row = $result->fetch_assoc() ){
                $jobProviderID = $row['jobProviderID'];
                $username = $row['username'];
                $email = $row['email'];
                $company_name = $row['company_name'];
                $jobID = $row['jobID'];
                $title = $row['title'];
                $salary1 = $row['salary1'];
                $salary2 = $row['salary2'];
                $description = $row['description'];
                $requirement = $row['requirement'];
                $level = $row['level'];
                $qualification = $row['qualification'];
                $experience = $row['experience'];
                $jobType = $row['jobType'];
                $specialization = $row['specialization'];
                $date = $row['date'];
                $reasonDisapprove = $row['reasonDisapprove'];
    ?>
        
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0" style="margin-left:10px; margin-right:10px">

                        <div class="col-sm-12">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h3>
                                <hr>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">JobProvider ID:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $jobProviderID ?></h6>
                                        <input type="hidden" name="jobProviderID" value="<?php echo $jobProviderID; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Username:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $username ?></h6>
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $email ?></h6>
                                        <input type="hidden" name="email" value="<?php echo $email; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Company Name:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $company_name ?></h6>
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job ID:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $jobID ?></h6>
                                        <input type="hidden" name="jobID" value="<?php echo $jobID; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job Title:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $title ?></h6>
                                        <input type="hidden" name="title" value="<?php echo $title; ?>" >
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job Descriptions:</p>
                                        <h6 class="text-muted f-w-400"><textarea style="padding:10px" rows="10" cols="66" readonly><?php echo $description ?></textarea></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job Requirements:</p>
                                        <h6 class="text-muted f-w-400"><textarea style="padding:10px" rows="10" cols="66" readonly><?php echo $requirement ?></textarea></h6>
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Salary:</p>
                                        <h6 class="text-muted f-w-400">RM<?php echo $salary1 ?>-<?php echo $salary2 ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Career Level:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $level ?></h6>
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Qualification:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $qualification ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Years of Experience:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $experience ?></h6>
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Job Type:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $jobType ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Specialization:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $specialization ?></h6>
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Created Date:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $date ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Comment(Reason of disapprove):</p>
                                        <h6 class="text-muted f-w-400"><input type="text" name="reasonDisapprove" class="reason" value="<?php echo $reasonDisapprove ?>"></h6>
                                    </div>
                                </div>

                                <hr>
                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="button">
                                    
                                        <input type="submit" class="btn btn-secondary" style="margin-left:39%" value="Back" name="Back">
                                        <input type="submit" class="btn btn-success" value="Approve" name="Approve">
                                        <input type="submit" class="btn btn-danger" value="Disapprove" name="Disapprove">

                                </div>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
        <?php }
            }?>
            </form>
            
            </div>
            </div>


        </div>
        </div>
<hr>
<div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                    <div class="h5 mb-2">Chat with us</div>
                    <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                    <div class="h5">Ask the community</div>
                    <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                    <div class="h5">Support center</div>
                    <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                </div>
                <div class="col">
                    <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                    <div class="h5">Call us</div>
                    <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                </div>
            </div>
        </div>

</section>
</main>
<footer class="bg-dark py-4 mt-auto">
    <div class="container px-5">
        <div class="row align-items-center justify-content-between flex-column flex-sm-row">
            <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
            <div class="col-auto">
                <a class="link-light small" href="#!">Privacy</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Terms</a>
                <span class="text-white mx-1">&middot;</span>
                <a class="link-light small" href="#!">Contact</a>
            </div>
        </div>
    </div>
</footer>
<!-- Bootstrap core JS-->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
<!-- Core theme JS-->
<script src="js/scripts.js"></script>
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<!-- * *                               SB Forms JS                               * *-->
<!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
<!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
<script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

<script>
    function checkerLogout(){
        var result = confirm('Are you sure you want to logout?');
        if(result == false){
            event.preventDefault();
        }
    }
</script>
</body>

</html>