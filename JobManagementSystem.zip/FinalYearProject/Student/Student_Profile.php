<?php 
    include ('../Connection.php');
    session_start();
    $email = $_SESSION['email'];

    //check got login or not
    if($email == ''){
        header('location: ../Visitor/Student_Login_Page.php');
    }

    $sql="SELECT * FROM login_student WHERE email = '$email'";
    $result=$conn->query($sql);

    if($result->num_rows>0){
        while($row = $result->fetch_assoc() ){
        $studentID = $row['studentID'];
        $username = $row['username'];
        $email = $row['email'];
        $country = $row['country'];
        $state = $row['state'];
        $postal_code = $row['postal_code'];
        $address = $row['address'];
        $phone_no = $row['phone_no'];
        $field = $row['field'];
        $photo = $row['photo'];
        $cv = $row['cv'];
        $comment = $row['comment'];
        }
    }

    if(isset($_POST['edit'])){
        header('location: Student_Edit_Profile.php');
    }

    if(isset($_POST['search'])){
        header('location: Student_Search_Profile.php');
    }
?>
<html>
    <head>
        <title>Student Profile</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
        <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.bundle.min.js" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/MaterialDesign-Webfont/3.6.95/css/materialdesignicons.css" rel="stylesheet">
        <link href="Student_Profile_CSS.css" rel="stylesheet">
        <link rel="icon" type="image/x-icon" href="../Visitor/assets/favicon.ico" />
        <!-- Bootstrap icons-->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
        <link href="../Visitor/css/styles.css" rel="stylesheet" />
        <style>
            body {
            width: 100%;
            height:100%;
            }
            h1,h2{
            text-align: center;
            }
        </style>
    </head>
    <body class="d-flex flex-column">
    <main class="flex-shrink-0">
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
                <div class="container px-5">
                    <a class="navbar-brand" href="Student_Home.php">Job Management System - Student</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="Student_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Applied_Job.php">Applied Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Favorite_Job.php">Favourite Job</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Contact_List.php">Contact</a></li>
                            <li class="nav-item"><a class="nav-link" href="Student_Profile.php">Profile</a></li>
                            <li class="nav-item"><a onclick="checkerLogout()" class="nav-link" href="Student_Logout.php" style="margin-right: 26px;">Logout</a></li>
                            <li class="nav-item"><span class="nav-link">Welcome: <?php echo $_SESSION['username'] ?></span></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">

            <h2 style="font-family: cursive;color:black;text-shadow: 2px 8px 6px rgba(0,0,0,0.2),0px -5px 35px rgba(255,255,255,0.3)"><b>Student Information</b></h2>

                <div class="container px-5">
                

                <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

                <div class="row gx-5 justify-content-center">

            <br>

            <form action="Student_Profile.php" method="post" id="contactForm">
        
                <div class="card user-card-full">
                    <div class="row m-l-0 m-r-0">
                        <div class="col-sm-4 bg-c-lite-green user-profile">
                            <div class="card-block text-center text-white">
                                <div class="m-b-25"> <img src="../Photo_Student/<?php echo $photo?>" class="img-radius" width="330px" height="360px"> </div>
                                
                            </div>
                        </div>
                        <div class="col-sm-8">
                            <div class="card-block">
                                <h3 class="m-b-20 p-b-5 b-b-default f-w-600">Information</h3>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Student ID:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $studentID ?></h6>
                                        <input type="hidden" name="studentID" value="<?php echo $studentID; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Username:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $username ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Email:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $email ?></h6>
                                        <input type="hidden" name="email" value="<?php echo $email; ?>" >
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Address:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $address ?>, <?php echo $state ?>, <?php echo $postal_code ?>, <?php echo $country ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Phone No:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $phone_no ?></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Field:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $field ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">CV:</p>
                                        <h6 class="text-muted f-w-400"><a href="../CV_Student/<?php echo $cv?>"><?php echo $cv?></a></h6>
                                    </div>
                                    <div class="col-sm-6">
                                        <p class="m-b-10 f-w-600">Comment:</p>
                                        <h6 class="text-muted f-w-400"><?php echo $comment ?></h6>
                                    </div>
                                </div>

                                <h6 class="m-b-20 p-b-5 b-b-default f-w-600"></h6>
                                <div class="button">
                                        <input type="submit" class="btn btn-success" name="edit" value="Edit Profile" style="margin-left:31%" >
                                        <input type="submit" value="Search For Others Profile" name="search" class="btn btn-warning">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
           
            </div>
        </div>

        <div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                            <div class="h5 mb-2">Chat with us</div>
                            <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                            <div class="h5">Ask the community</div>
                            <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                            <div class="h5">Support center</div>
                            <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                            <div class="h5">Call us</div>
                            <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                        </div>
                    </div>
                </div>

        </section>
    </main>
    <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

        <script>
            function checkerLogout(){
                var result = confirm('Are you sure you want to logout?');
                if(result == false){
                    event.preventDefault();
                }
            }
        </script>

    </body>
</html>