<?php
    require_once "JobProvider_ControlUserData.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Wait approved</title>
    <link rel="stylesheet" type="text/css" href="JobProvider_Success_Email_Verify_CSS.css">
    <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Bootstrap icons-->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.5.0/font/bootstrap-icons.css" rel="stylesheet" />
    <link href="css/styles.css" rel="stylesheet" />
</head>

<body class="d-flex flex-column">
        <main class="flex-shrink-0">
        <nav class="navbar navbar-expand-lg navbar-dark" style="background-color:Indigo">
                <div class="container px-5">
                    <a class="navbar-brand" href="JobProvider_Home.php">Job Management System - JobProvider</a>
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Home.php">Home</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Register_Page.php">Register</a></li>
                            <li class="nav-item"><a class="nav-link" href="JobProvider_Login_Page.php" style="margin-right: 26px;">Login</a></li>
                            <li class="nav-item"><a class="nav-link" href="Home.php">For Student</a></li>
                        </ul>
                    </div>
                </div>
            </nav>

            <section class="py-5">
            <div class="container px-5">
            

            <div class="bg-light rounded-3 py-10 px-10 px-md-5 mb-5">

            <div class="row gx-5 justify-content-center">
            <div class="col-lg-8 col-xl-6">

    <form id="contactForm" action="JobProvider_Login_Page.php">
        <span class="form_title" style="font-size: 46px;"><u>Wait For Approved</u></span></br><br>
        <span class="form_description">Oops! Looks like your registration request is still being approved.</span><br>
        <span class="form_description">Please wait about 3-4 days for approving your registeration. </span><br>
        <span class="form_description">Thank you and have a nice day !!!<span></br></br>
        <input class="form_button" type="submit" value="Back to login page" formnovalidate/><br><br>
    </form>

    </div>
                </div>
                </div>

                <div class="row gx-5 row-cols-2 row-cols-lg-4 py-5">
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-chat-dots"></i></div>
                            <div class="h5 mb-2">Chat with us</div>
                            <p class="text-muted mb-0">Chat live with one of our support specialists.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-people"></i></div>
                            <div class="h5">Ask the community</div>
                            <p class="text-muted mb-0">Explore our community forums and communicate with other users.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-question-circle"></i></div>
                            <div class="h5">Support center</div>
                            <p class="text-muted mb-0">Email us (B190202C@sc.edu.my) for any supports.</p>
                        </div>
                        <div class="col">
                            <div class="feature bg-primary bg-gradient text-white rounded-3 mb-3"><i class="bi bi-telephone"></i></div>
                            <div class="h5">Call us</div>
                            <p class="text-muted mb-0">Call us during normal business hours at 000-000-0000.</p>
                        </div>
                    </div>
                </div>
            </section>
        </main>
        <!-- Footer-->
        <footer class="bg-dark py-4 mt-auto">
            <div class="container px-5">
                <div class="row align-items-center justify-content-between flex-column flex-sm-row">
                    <div class="col-auto"><div class="small m-0 text-white">Copyright &copy; Job Management System 2021</div></div>
                    <div class="col-auto">
                        <a class="link-light small" href="#!">Privacy</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Terms</a>
                        <span class="text-white mx-1">&middot;</span>
                        <a class="link-light small" href="#!">Contact</a>
                    </div>
                </div>
            </div>
        </footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>

</body>
</html>